<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="534"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="535"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="93"/>
        <source>More info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="167"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="169"/>
        <source>Info</source>
        <translation>Bilgi</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="171"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="173"/>
        <source>Version</source>
        <translation>Sürüm</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="175"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Size</source>
        <translation>Boyut</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>MX Package Installer</source>
        <translation>MX Paket Kurucusu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Gözde Uygulamalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Yaygın kullanılan paketleri yönetin&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="964"/>
        <location filename="../src/mainwindow.ui" line="1355"/>
        <location filename="../src/mainwindow.ui" line="1476"/>
        <location filename="../src/mainwindow.ui" line="1864"/>
        <source>search</source>
        <translation>Ara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="669"/>
        <location filename="../src/mainwindow.ui" line="989"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>= Installed packages</source>
        <translation>= Kurulu paketler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Etkin Depolar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1552"/>
        <source>Upgrade All</source>
        <translation>Hepsini Yükselt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="808"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>Installed:</source>
        <translation>Kurulu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="801"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Total packages:</source>
        <translation>Toplam paket sayısı:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <location filename="../src/mainwindow.ui" line="1260"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Ayrıca &quot;Önerilen&quot; Paketleri Kur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="838"/>
        <location filename="../src/mainwindow.ui" line="1185"/>
        <source>Upgradable:</source>
        <translation>Yükseltilebilir:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1220"/>
        <source>Hide library and developer packages</source>
        <translation>Kütüphane ve geliştirici paketlerini gizle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="600"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <location filename="../src/mainwindow.ui" line="1279"/>
        <location filename="../src/mainwindow.ui" line="1764"/>
        <location filename="../src/mainwindow.ui" line="1874"/>
        <source>Refresh list</source>
        <translation>Listeyi Yenile</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="728"/>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <location filename="../src/mainwindow.ui" line="1816"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Paketleri durumlarına göre süzün.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="735"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <location filename="../src/mainwindow.ui" line="1058"/>
        <location filename="../src/mainwindow.ui" line="1388"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.cpp" line="5347"/>
        <source>All packages</source>
        <translation>Tüm paketler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="740"/>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.ui" line="1397"/>
        <location filename="../src/mainwindow.cpp" line="5373"/>
        <source>Installed</source>
        <translation>Kuruldu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="5374"/>
        <source>Upgradable</source>
        <translation>Yükseltilebilir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1073"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.ui" line="1756"/>
        <location filename="../src/mainwindow.cpp" line="5340"/>
        <location filename="../src/mainwindow.cpp" line="5375"/>
        <source>Not installed</source>
        <translation>Kurulu değil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.ui" line="1078"/>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <location filename="../src/mainwindow.cpp" line="4513"/>
        <location filename="../src/mainwindow.cpp" line="5311"/>
        <location filename="../src/mainwindow.cpp" line="5376"/>
        <location filename="../src/mainwindow.cpp" line="5459"/>
        <location filename="../src/mainwindow.cpp" line="5550"/>
        <source>Autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <location filename="../src/mainwindow.ui" line="1020"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Yükseltilebilir paket. Seçilen depoda daha yeni sürüm mevcut.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>MX Test Repo</source>
        <translation>MX Test Deposu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1687"/>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>For all users</source>
        <translation>Tüm kullanıcılar için</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1696"/>
        <source>For current user</source>
        <translation>Şu anki kullanıcı için</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1781"/>
        <source>Remote (repo):</source>
        <translation>Uzak (depo):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1722"/>
        <location filename="../src/mainwindow.ui" line="1726"/>
        <location filename="../src/mainwindow.cpp" line="5322"/>
        <source>All apps</source>
        <translation>Tüm uygulamalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1731"/>
        <location filename="../src/mainwindow.cpp" line="5328"/>
        <source>All runtimes</source>
        <translation>Tüm çalışma zamanları</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1736"/>
        <location filename="../src/mainwindow.cpp" line="5334"/>
        <source>All available</source>
        <translation>Hepsi mevcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1741"/>
        <location filename="../src/mainwindow.cpp" line="5319"/>
        <source>Installed apps</source>
        <translation>Yüklü uygulamalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1746"/>
        <location filename="../src/mainwindow.cpp" line="5316"/>
        <source>Installed runtimes</source>
        <translation>Yüklü çalışma zamanları</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1751"/>
        <location filename="../src/mainwindow.cpp" line="5338"/>
        <source>All installed</source>
        <translation>Hepsi yüklendi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1531"/>
        <location filename="../src/mainwindow.ui" line="1941"/>
        <source>Total items </source>
        <translation>Toplam öğe sayısı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1545"/>
        <source>Installed apps:</source>
        <translation>Yüklü uygulamalar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1597"/>
        <source>Advanced</source>
        <translation>Gelişmiş</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1626"/>
        <source>Total installed size:</source>
        <translation>Toplam kurulu büyüklük:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1640"/>
        <source>Remove unused runtimes</source>
        <translation>Kullanılmayan runtime paketlerini kaldır</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="613"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>AUR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="656"/>
        <source>search AUR (type to find more)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="763"/>
        <source>Tip: search to find other AUR packages. Installed AUR packages are shown when the search box is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <location filename="../src/mainwindow.ui" line="1230"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1798"/>
        <source>Snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1819"/>
        <location filename="../src/mainwindow.ui" line="1823"/>
        <location filename="../src/mainwindow_snap.cpp" line="234"/>
        <location filename="../src/mainwindow_snap.cpp" line="310"/>
        <source>Installed snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1828"/>
        <location filename="../src/mainwindow.cpp" line="5197"/>
        <location filename="../src/mainwindow_snap.cpp" line="149"/>
        <location filename="../src/mainwindow_snap.cpp" line="237"/>
        <location filename="../src/mainwindow_snap.cpp" line="239"/>
        <source>Search store</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1861"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1893"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1903"/>
        <source>Set up Snap support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1955"/>
        <source>Installed snaps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1982"/>
        <source>Update All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2005"/>
        <location filename="../src/mainwindow.cpp" line="4762"/>
        <location filename="../src/mainwindow.cpp" line="5153"/>
        <source>Console Output</source>
        <translation>Uçbirim Çıktısı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2011"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2021"/>
        <source>Respond here, or just press Enter</source>
        <translation>Burada cevaplayın veya sadece Enter’a basın</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2080"/>
        <location filename="../src/mainwindow.cpp" line="2657"/>
        <location filename="../src/mainwindow.cpp" line="5360"/>
        <location filename="../src/mainwindow.cpp" line="5371"/>
        <location filename="../src/mainwindow.cpp" line="5489"/>
        <location filename="../src/mainwindow.cpp" line="5529"/>
        <location filename="../src/mainwindow.cpp" line="5549"/>
        <location filename="../src/mainwindow.cpp" line="5590"/>
        <location filename="../src/mainwindow_snap.cpp" line="295"/>
        <source>Install</source>
        <translation>Kur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2086"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2105"/>
        <source>Quit application</source>
        <translation>Uygulamadan çık</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2108"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2114"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2146"/>
        <source>About this application</source>
        <translation>Uygulama hakkında</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2149"/>
        <source>About...</source>
        <translation>Hakkında...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2155"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2193"/>
        <source>Display help </source>
        <translation>Yardımı görüntüle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2196"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2202"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2218"/>
        <source>Uninstall</source>
        <translation>Kaldır</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2224"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1067"/>
        <source>Uninstalling packages...</source>
        <translation>Paketler kaldırılıyor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1072"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Kaldırma öncesi işlemler çalıştırılıyor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1090"/>
        <source>Running post-uninstall operations...</source>
        <translation>Kaldırma sonrası işlemler çalıştırılıyor ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1107"/>
        <source>Refreshing sources...</source>
        <translation>Kaynaklar yenileniyor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="577"/>
        <location filename="../src/mainwindow.cpp" line="1120"/>
        <location filename="../src/mainwindow.cpp" line="2710"/>
        <location filename="../src/mainwindow.cpp" line="2731"/>
        <location filename="../src/mainwindow.cpp" line="2751"/>
        <location filename="../src/mainwindow.cpp" line="2925"/>
        <location filename="../src/mainwindow.cpp" line="3126"/>
        <location filename="../src/mainwindow.cpp" line="3208"/>
        <location filename="../src/mainwindow.cpp" line="3265"/>
        <location filename="../src/mainwindow.cpp" line="3639"/>
        <location filename="../src/mainwindow.cpp" line="3793"/>
        <location filename="../src/mainwindow.cpp" line="4445"/>
        <location filename="../src/mainwindow.cpp" line="4523"/>
        <location filename="../src/mainwindow.cpp" line="4689"/>
        <location filename="../src/mainwindow.cpp" line="4752"/>
        <location filename="../src/mainwindow.cpp" line="4937"/>
        <location filename="../src/mainwindow.cpp" line="4989"/>
        <location filename="../src/mainwindow.cpp" line="5647"/>
        <location filename="../src/mainwindow.cpp" line="5701"/>
        <location filename="../src/mainwindow.cpp" line="5833"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5975"/>
        <location filename="../src/mainwindow.cpp" line="6024"/>
        <location filename="../src/mainwindow_snap.cpp" line="33"/>
        <location filename="../src/mainwindow_aur.cpp" line="143"/>
        <location filename="../src/mainwindow_aur.cpp" line="175"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1121"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Kaynaklar güncellenirken bir sorun oluştu. Bazı kaynaklar güncellenmemiş olabilir. Daha fazla bilgi için:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <location filename="../src/mainwindow.cpp" line="1283"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1289"/>
        <source>Debian Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1812"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1818"/>
        <source>Please wait...</source>
        <translation>Lütfen bekleyin...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2450"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Paketleri yalnızca deneme amacıyla sağlanan MX Test deposunu kullanmak üzeresiniz. Sisteminizi bozma olasılığı vardır, bu nedenle sisteminizi yedeklemeniz ve bir seferde yalnızca bir paketi yüklemeniz veya güncellemeniz önerilir. Lütfen Forum’da geri bildirimde bulunun, böylece paket Ana Depoya geçmeden önce değerlendirilebilir.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2459"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Bir sonraki Debian sürümünden (‘testing’ olarak adlandırılır) alınan paketleri içeren Debian Backports’u kullanmak üzeresiniz. Debian kararlı sürümünde kullanılmak üzere ayarlanmış ve yeniden derlenmiştir. Debian ve antiX Linux’un kararlı sürümlerinde olduğu gibi kapsamlı bir şekilde test edilememekteler ve Debian Kararlı Sürümdeki diğer bileşenlerle uyumsuzluk riskiyle beraber &quot;oldukları gibi&quot; sağlanmaktalar. Dikkatli kullanın!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2467"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux, yalnızca kullanıcıların rahatlığı için flatpaks deposunu içerir ve bireysel flatpaks’ların işlevselliğinden sorumlu değildir. Daha fazla bilgi için Wiki’deki flatpaks’e bakın.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2483"/>
        <location filename="../src/mainwindow.cpp" line="6014"/>
        <source>Warning</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2485"/>
        <source>Do not show this message again</source>
        <translation>Bu iletiyi tekrar gösterme</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2654"/>
        <source>Remove</source>
        <translation>Kaldır</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2550"/>
        <location filename="../src/mainwindow.cpp" line="2670"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Aşağıdaki paketler seçildi. Değişikliklerin listesi için Ayrıntıları Göster’e tıklayın.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2711"/>
        <location filename="../src/mainwindow.cpp" line="2926"/>
        <location filename="../src/mainwindow.cpp" line="3209"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>İnternete bağlı değilsiniz, paket listesi indirilemeyecek.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2714"/>
        <source>Installing packages...</source>
        <translation>Paketler kuruluyor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2845"/>
        <source>Post-processing...</source>
        <translation>Son işlem...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2877"/>
        <source>Pre-processing for </source>
        <translation>Ön işlemi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2892"/>
        <source>Installing </source>
        <translation>Kuruluyor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2902"/>
        <source>Post-processing for </source>
        <translation>Son işlemi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3123"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3216"/>
        <source>Downloading package info...</source>
        <translation>Paket bilgisi indiriliyor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3907"/>
        <location filename="../src/mainwindow.cpp" line="4054"/>
        <location filename="../src/mainwindow.cpp" line="4205"/>
        <location filename="../src/mainwindow.cpp" line="4249"/>
        <source>Package info</source>
        <translation>Paket bilgisi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3943"/>
        <location filename="../src/mainwindow.cpp" line="5908"/>
        <source>More &amp;info...</source>
        <translation>Daha fazla b&amp;ilgi...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4154"/>
        <source>Packages to be installed: </source>
        <translation>Kurulacak paketler:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4441"/>
        <location filename="../src/mainwindow.cpp" line="4498"/>
        <location filename="../src/mainwindow.cpp" line="4520"/>
        <location filename="../src/mainwindow.cpp" line="4685"/>
        <location filename="../src/mainwindow.cpp" line="4731"/>
        <location filename="../src/mainwindow.cpp" line="5698"/>
        <location filename="../src/mainwindow.cpp" line="5829"/>
        <location filename="../src/mainwindow.cpp" line="5862"/>
        <location filename="../src/mainwindow.cpp" line="5971"/>
        <location filename="../src/mainwindow_snap.cpp" line="492"/>
        <source>Done</source>
        <translation>Tamamlandı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4441"/>
        <location filename="../src/mainwindow.cpp" line="4498"/>
        <location filename="../src/mainwindow.cpp" line="4520"/>
        <location filename="../src/mainwindow.cpp" line="4685"/>
        <location filename="../src/mainwindow.cpp" line="4731"/>
        <location filename="../src/mainwindow.cpp" line="4749"/>
        <location filename="../src/mainwindow.cpp" line="5698"/>
        <location filename="../src/mainwindow.cpp" line="5829"/>
        <location filename="../src/mainwindow.cpp" line="5862"/>
        <location filename="../src/mainwindow.cpp" line="5971"/>
        <location filename="../src/mainwindow.cpp" line="6021"/>
        <location filename="../src/mainwindow_snap.cpp" line="492"/>
        <source>Processing finished successfully.</source>
        <translation>İşlem Başarıyla Sonuçlandı.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4436"/>
        <location filename="../src/mainwindow.cpp" line="4496"/>
        <location filename="../src/mainwindow.cpp" line="5857"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="578"/>
        <location filename="../src/mainwindow.cpp" line="3640"/>
        <location filename="../src/mainwindow.cpp" line="3794"/>
        <source>The installed-package query returned an error. Please check the log for details.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1753"/>
        <source>Show/hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1758"/>
        <source>Clear input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2474"/>
        <source>You are about to use the AUR, which contains user-contributed packages. These packages are not vetted by the distribution, may be outdated, and could contain malicious or broken build scripts. Use with care.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2732"/>
        <source>paru is not installed.

To install AUR packages, please install paru first:
pacman -S paru

Then try installing the AUR package again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2752"/>
        <source>AUR packages cannot be built as root, and no regular user could be found to build as.

Install the package as your normal user instead.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3122"/>
        <source>The download timed out. Please check your internet connection and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4037"/>
        <source>Developer: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4040"/>
        <source>License: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4044"/>
        <source>Homepage: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4138"/>
        <location filename="../src/mainwindow.cpp" line="4206"/>
        <location filename="../src/mainwindow_snap.cpp" line="567"/>
        <location filename="../src/mainwindow_aur.cpp" line="153"/>
        <source>No information available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <location filename="../src/mainwindow.cpp" line="4524"/>
        <location filename="../src/mainwindow.cpp" line="5702"/>
        <location filename="../src/mainwindow.cpp" line="5834"/>
        <location filename="../src/mainwindow.cpp" line="5869"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Kurulum sırasında bir hata saptandı, lütfen uçbirim çıktısını kontrol edin.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4465"/>
        <source>Install snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4477"/>
        <source>Installing packages: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4480"/>
        <source>Installing package: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4501"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4536"/>
        <source>About %1</source>
        <translation>%1 Hakkında </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4537"/>
        <source>Version: </source>
        <translation>Sürüm</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4539"/>
        <source>Package Installer for MX Linux</source>
        <translation>MX Linux  Paket Kurucu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4541"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4542"/>
        <source>%1 License</source>
        <translation>%1 Lisans</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4550"/>
        <location filename="../src/mainwindow.cpp" line="4552"/>
        <source>%1 Help</source>
        <translation>%1 Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4666"/>
        <location filename="../src/mainwindow.cpp" line="5964"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4675"/>
        <location filename="../src/mainwindow.cpp" line="4729"/>
        <location filename="../src/mainwindow.cpp" line="5966"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4676"/>
        <location filename="../src/mainwindow.cpp" line="5967"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4689"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Kaldırma işlemi sırasında bir sorunla karşılaştık, lütfen çıktıyı kontrol edin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4709"/>
        <source>Remove snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4710"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4734"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4749"/>
        <location filename="../src/mainwindow.cpp" line="6021"/>
        <source>Success</source>
        <translation>Başarılı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4752"/>
        <location filename="../src/mainwindow.cpp" line="6024"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>programı kaldırırken bir hata ile karşılaştık.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3266"/>
        <location filename="../src/mainwindow.cpp" line="4938"/>
        <location filename="../src/mainwindow.cpp" line="4990"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Paket listesi indirilemedi. Lütfen APT kaynaklarınızı kontrol edin.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="144"/>
        <source>paru is not installed.

Install it with: pacman -S paru</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="176"/>
        <source>Could not query AUR packages. Please check that paru is installed and you are online.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5072"/>
        <location filename="../src/mainwindow.cpp" line="5130"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak kurulu değil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5073"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak şu anda yüklü değil.
Devam edip yüklensin mi?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5130"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak kurulmadı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5157"/>
        <location filename="../src/mainwindow_snap.cpp" line="471"/>
        <source>Needs re-login</source>
        <translation>Yeniden giriş gerekiyor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5158"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Menüdeki yüklü öğeleri görmek için oturumu kapatıp açmanız gerekebilir.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No results</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="368"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="392"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="458"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="463"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="467"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="497"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5360"/>
        <location filename="../src/mainwindow.cpp" line="5371"/>
        <location filename="../src/mainwindow.cpp" line="5487"/>
        <location filename="../src/mainwindow.cpp" line="5551"/>
        <source>Mark keep</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5387"/>
        <source>Select/deselect all upgradable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5388"/>
        <source>Select/deselect all autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5489"/>
        <location filename="../src/mainwindow.cpp" line="5549"/>
        <source>Upgrade</source>
        <translation>Yükselt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5754"/>
        <source>Show input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5754"/>
        <source>Hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5763"/>
        <location filename="../src/mainwindow.cpp" line="5919"/>
        <source>Quit?</source>
        <translation>Vazgeçilsin mi?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5764"/>
        <location filename="../src/mainwindow.cpp" line="5920"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>İşlem devam ediyor, vazgeçmek sistemi kararsız duruma getirebilir. &lt;p&gt;&lt;b&gt;MX paket kurucudan çıkmak istediğinizden emin misiniz?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5529"/>
        <source>Reinstall</source>
        <translation>Yeniden kur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="472"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5826"/>
        <location filename="../src/mainwindow_snap.cpp" line="489"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5648"/>
        <location filename="../src/mainwindow.cpp" line="5976"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Son işlem sırasında sorun algılandı, lütfen konsol çıktısını kontrol edin.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="6015"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Potansiyel tehlikeli işlem.
Lütfen kaldırılacak paketlerin listesini dikkatlice kontrol ettiğinizden emin olun.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Flatpak Uzaktan Yönetme</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Tüm kullanıcılar için</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Şu anki kullanıcı için</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>Flatpak uzak adresi girin</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>uygulamayı yüklemek için Flatpakref konumunu girin</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Flatpak uzak depolarını ekleyin, kaldırın veya flatpakref adresini, yolunu kullanarak uygulamaları yükleyin</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Uzaktan kumandayı kaldır</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Uzaktan kumanda ekle</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Uygulamayı yükle</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="85"/>
        <source>Not removable</source>
        <translation>Çıkarılabilir değil</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="86"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub ana uzak Flatpak depodur ve kaldırılmayacaktır</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="100"/>
        <source>Error removing remote</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Could not remove remote - command returned an error. Please try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="118"/>
        <source>Error adding remote</source>
        <translation>Uzaktakini ekleme başarısız</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="119"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Uzaktan komut eklenemedi bir hata olarak döndü. Lütfen uzak adresi iki kez kontrol edin ve tekrar deneyin</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="124"/>
        <source>Success</source>
        <translation>Başarılı</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="124"/>
        <source>Remote added successfully</source>
        <translation>Uzaktaki başarıyla eklendi</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="148"/>
        <source>Repo Version</source>
        <translation>Depo Sürümü</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="150"/>
        <source>Installed</source>
        <translation>Kuruldu</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="152"/>
        <source>Description</source>
        <translation>Açıklama</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Bilgi</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Açıklama</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <location filename="../src/about.cpp" line="113"/>
        <source>Changelog</source>
        <translation>Değişim günlüğü</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="123"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="126"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="85"/>
        <location filename="../src/lockfile_apt.cpp" line="52"/>
        <source>Warning</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="53"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Dpkg/apt veritabanı başka bir program tarafından kilitlendi: %1
Programı kapatın veya işlemin tamamlanmasını bekleyip tekrar deneyin.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="87"/>
        <source>another package manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Paket Yükleyici, MX Linux’ta paketleri yönetmek için kullanılan bir araçtır 
    - farklı kaynaklardan popüler programları yükler 
    - MX Test deposundan programları yükler 
    - Debian Backports deposundan programları yükler 
    - flatpak’ları yükler</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Yanlışlıkla internet erişimi olmadığını bildiriyorsa çevrimiçi kontrolü atlayın.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="111"/>
        <location filename="../src/main.cpp" line="119"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Görünüşe göre root olarak girmişsiniz, lütfen çıkın ve bu programı kullanmak için normal kullanıcı olarak girin. </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>You must run this program with admin access.</source>
        <translation>Bu programı yönetici erişimiyle çalıştırmalısınız.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="86"/>
        <source>Pacman database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="89"/>
        <source>More info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="157"/>
        <source>Info</source>
        <translation>Bilgi</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Sürüm</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="161"/>
        <source>Publisher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="163"/>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="165"/>
        <source>Description</source>
        <translation>Açıklama</translation>
    </message>
</context>
</TS>