<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="534"/>
        <source>Administrator Access Required</source>
        <translation>Требуется доступ администратора</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="535"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation>Эта операция требует прав администратора. Попробуйте выполнить действие снова и введите пароль при появлении запроса.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="93"/>
        <source>More info</source>
        <translation>Подробности</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="167"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="169"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="171"/>
        <source>Full Name</source>
        <translation>Полное имя</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="173"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="175"/>
        <source>Branch</source>
        <translation>Ветка</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="746"/>
        <source>MX Package Installer</source>
        <translation>MX Установщик пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Популярные приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Управление популярными пакетами&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="964"/>
        <location filename="../src/mainwindow.ui" line="1355"/>
        <location filename="../src/mainwindow.ui" line="1476"/>
        <location filename="../src/mainwindow.ui" line="1864"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="669"/>
        <location filename="../src/mainwindow.ui" line="989"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>= Installed packages</source>
        <translation>= Установленные пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Включённые репозитории</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Удалите все пакеты, помеченные как &amp;quot;автоудаляемые&amp;quot;. Если вы хотите управлять ими, выберите «Автоудаляемые» в раскрывающемся списке.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Автоматическое удаление пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1552"/>
        <source>Upgrade All</source>
        <translation>Обновить все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="808"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>Installed:</source>
        <translation>Установлено:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="801"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Total packages:</source>
        <translation>Всего пакетов:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <location filename="../src/mainwindow.ui" line="1260"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Также устанавливать &quot;Рекомендуемые&quot; пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="838"/>
        <location filename="../src/mainwindow.ui" line="1185"/>
        <source>Upgradable:</source>
        <translation>Доступно обновление:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1220"/>
        <source>Hide library and developer packages</source>
        <translation>Скрыть библиотеки и пакеты для разработчиков</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="600"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <location filename="../src/mainwindow.ui" line="1279"/>
        <location filename="../src/mainwindow.ui" line="1764"/>
        <location filename="../src/mainwindow.ui" line="1874"/>
        <source>Refresh list</source>
        <translation>Обновить список</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="728"/>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <location filename="../src/mainwindow.ui" line="1816"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Фильтровать пакеты в зависимости от их статуса.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="735"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <location filename="../src/mainwindow.ui" line="1058"/>
        <location filename="../src/mainwindow.ui" line="1388"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.cpp" line="5349"/>
        <source>All packages</source>
        <translation>Все пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="740"/>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.ui" line="1397"/>
        <location filename="../src/mainwindow.cpp" line="5375"/>
        <source>Installed</source>
        <translation>Установлено</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="5376"/>
        <source>Upgradable</source>
        <translation>Доступно обновление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1073"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.ui" line="1756"/>
        <location filename="../src/mainwindow.cpp" line="5342"/>
        <location filename="../src/mainwindow.cpp" line="5377"/>
        <source>Not installed</source>
        <translation>Не установлено</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.ui" line="1078"/>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <location filename="../src/mainwindow.cpp" line="2078"/>
        <location filename="../src/mainwindow.cpp" line="2132"/>
        <location filename="../src/mainwindow.cpp" line="5313"/>
        <location filename="../src/mainwindow.cpp" line="5378"/>
        <location filename="../src/mainwindow.cpp" line="5438"/>
        <source>Autoremovable</source>
        <translation>Автоудаляемый</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <location filename="../src/mainwindow.ui" line="1020"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Обновляемый пакет. Более новая версия доступна в выбранном репозитории.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>MX Test Repo</source>
        <translation>Тестовый репозиторий MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Debian Backports</source>
        <translation>Бэкпорты Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <source>Flatpaks</source>
        <translation>Flatpak</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1687"/>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>For all users</source>
        <translation>Для всех пользователей</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1696"/>
        <source>For current user</source>
        <translation>Для текущего пользователя</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1781"/>
        <source>Remote (repo):</source>
        <translation>Внешний репозиторий:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1722"/>
        <location filename="../src/mainwindow.ui" line="1726"/>
        <location filename="../src/mainwindow.cpp" line="5324"/>
        <source>All apps</source>
        <translation>Все приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1731"/>
        <location filename="../src/mainwindow.cpp" line="5330"/>
        <source>All runtimes</source>
        <translation>Все среды выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1736"/>
        <location filename="../src/mainwindow.cpp" line="5336"/>
        <source>All available</source>
        <translation>Все доступные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1741"/>
        <location filename="../src/mainwindow.cpp" line="5321"/>
        <source>Installed apps</source>
        <translation>Установленные приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1746"/>
        <location filename="../src/mainwindow.cpp" line="5318"/>
        <source>Installed runtimes</source>
        <translation>Установленные среды выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1751"/>
        <location filename="../src/mainwindow.cpp" line="5340"/>
        <source>All installed</source>
        <translation>Все установленные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1531"/>
        <location filename="../src/mainwindow.ui" line="1941"/>
        <source>Total items </source>
        <translation>Всего элементов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1545"/>
        <source>Installed apps:</source>
        <translation>Установленные приложения:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1597"/>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1626"/>
        <source>Total installed size:</source>
        <translation>Общий размер установленного:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1640"/>
        <source>Remove unused runtimes</source>
        <translation>Удалить неиспользуемые среды выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="613"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>AUR</source>
        <translation>AUR</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="656"/>
        <source>search AUR (type to find more)</source>
        <translation>поиск в AUR (введите для поиска)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="763"/>
        <source>Tip: search to find other AUR packages. Installed AUR packages are shown when the search box is empty.</source>
        <translation>Совет: выполните поиск, чтобы найти другие пакеты AUR. Установленные пакеты AUR отображаются, когда поле поиска пусто.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <location filename="../src/mainwindow.ui" line="1230"/>
        <source>Only repo packages</source>
        <translation>Только пакеты репозитория</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1798"/>
        <source>Snaps</source>
        <translation>Snap</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1819"/>
        <location filename="../src/mainwindow.ui" line="1823"/>
        <location filename="../src/mainwindow_snap.cpp" line="234"/>
        <location filename="../src/mainwindow_snap.cpp" line="310"/>
        <source>Installed snaps</source>
        <translation>Установленные пакеты Snap</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1828"/>
        <location filename="../src/mainwindow.cpp" line="5207"/>
        <location filename="../src/mainwindow_snap.cpp" line="149"/>
        <location filename="../src/mainwindow_snap.cpp" line="237"/>
        <location filename="../src/mainwindow_snap.cpp" line="239"/>
        <source>Search store</source>
        <translation>Поиск в магазине</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1861"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Введите запрос и нажмите Enter для поиска в магазине Snap.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1893"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation>Поддержка Snap не настроена в этой системе. Нажмите кнопку, чтобы установить snapd и включить службу Snap.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1903"/>
        <source>Set up Snap support</source>
        <translation>Настроить поддержку Snap</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1955"/>
        <source>Installed snaps:</source>
        <translation>Установленные пакеты Snap:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1982"/>
        <source>Update All</source>
        <translation>Обновить все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2005"/>
        <location filename="../src/mainwindow.cpp" line="4772"/>
        <location filename="../src/mainwindow.cpp" line="5163"/>
        <source>Console Output</source>
        <translation>Вывод консоли</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2011"/>
        <source>Enter</source>
        <translation>Ввод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2021"/>
        <source>Respond here, or just press Enter</source>
        <translation>Введите ответ здесь или просто нажмите Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2080"/>
        <location filename="../src/mainwindow.cpp" line="2718"/>
        <location filename="../src/mainwindow.cpp" line="5362"/>
        <location filename="../src/mainwindow.cpp" line="5373"/>
        <location filename="../src/mainwindow.cpp" line="5453"/>
        <location filename="../src/mainwindow.cpp" line="5492"/>
        <location filename="../src/mainwindow.cpp" line="5512"/>
        <location filename="../src/mainwindow.cpp" line="5553"/>
        <location filename="../src/mainwindow_snap.cpp" line="295"/>
        <source>Install</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2086"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2105"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2108"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2114"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2146"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2149"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2155"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2193"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2196"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2202"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2218"/>
        <source>Uninstall</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2224"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1028"/>
        <source>Uninstalling packages...</source>
        <translation>Удаление пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1033"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Запуск предварительных операций перед удалением...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1051"/>
        <source>Running post-uninstall operations...</source>
        <translation>Запуск операций после удаления...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Refreshing sources...</source>
        <translation>Обновление источников...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="538"/>
        <location filename="../src/mainwindow.cpp" line="1081"/>
        <location filename="../src/mainwindow.cpp" line="2771"/>
        <location filename="../src/mainwindow.cpp" line="2792"/>
        <location filename="../src/mainwindow.cpp" line="2812"/>
        <location filename="../src/mainwindow.cpp" line="2986"/>
        <location filename="../src/mainwindow.cpp" line="3187"/>
        <location filename="../src/mainwindow.cpp" line="3269"/>
        <location filename="../src/mainwindow.cpp" line="3326"/>
        <location filename="../src/mainwindow.cpp" line="3695"/>
        <location filename="../src/mainwindow.cpp" line="3803"/>
        <location filename="../src/mainwindow.cpp" line="4455"/>
        <location filename="../src/mainwindow.cpp" line="4533"/>
        <location filename="../src/mainwindow.cpp" line="4699"/>
        <location filename="../src/mainwindow.cpp" line="4762"/>
        <location filename="../src/mainwindow.cpp" line="4947"/>
        <location filename="../src/mainwindow.cpp" line="4999"/>
        <location filename="../src/mainwindow.cpp" line="5610"/>
        <location filename="../src/mainwindow.cpp" line="5664"/>
        <location filename="../src/mainwindow.cpp" line="5796"/>
        <location filename="../src/mainwindow.cpp" line="5831"/>
        <location filename="../src/mainwindow.cpp" line="5938"/>
        <location filename="../src/mainwindow.cpp" line="5987"/>
        <location filename="../src/mainwindow_snap.cpp" line="33"/>
        <location filename="../src/mainwindow_aur.cpp" line="153"/>
        <location filename="../src/mainwindow_aur.cpp" line="185"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1082"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Возникла проблема с обновлением источников. Возможно, некоторые источники не предоставили обновления. Для получения дополнительной информации проверьте:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1217"/>
        <location filename="../src/mainwindow.cpp" line="1244"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Не удалось определить версию Debian. Выберите вашу версию:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1250"/>
        <source>Debian Version</source>
        <translation>Версия Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1783"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1789"/>
        <source>Please wait...</source>
        <translation>Пожалуйста, подождите...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2511"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Вы собираетесь использовать тестовый репозиторий MX, пакеты которого предоставляются только для тестирования. Возможно, они могут повредить вашу систему, поэтому рекомендуется создать резервную копию системы и устанавливать или обновлять только один пакет за раз. Пожалуйста, оставьте отзыв на Форуме, чтобы пакет мог быть оценён перед переносом в основной репозиторий.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2520"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Вы собираетесь использовать Debian Backports, который содержит пакеты, взятые из следующего выпуска Debian (называемого &apos;testing&apos;), настроенные и перекомпилированные для использования в Debian stable. Они не могут быть протестированы так же тщательно, как в стабильных версиях Debian и MX Linux, и предоставляются &quot;как есть&quot;, с риском несовместимости с другими компонентами в Debian stable. Используйте с осторожностью!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2528"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux включает этот репозиторий Flatpak только для удобства пользователей и не несёт ответственности за их функционирование. Подробнее о Flatpak в Вики.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2544"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2546"/>
        <source>Do not show this message again</source>
        <translation>Не показывать это сообщение снова</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2715"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2611"/>
        <location filename="../src/mainwindow.cpp" line="2731"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Следующие пакеты были выбраны. Нажмите «Показать подробности» для просмотра списка изменений.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2772"/>
        <location filename="../src/mainwindow.cpp" line="2987"/>
        <location filename="../src/mainwindow.cpp" line="3270"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Интернет недоступен, невозможно загрузить список пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2775"/>
        <source>Installing packages...</source>
        <translation>Установка пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2906"/>
        <source>Post-processing...</source>
        <translation>Обработка...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2948"/>
        <source>Pre-processing for </source>
        <translation>Предварительная обработка для</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2958"/>
        <source>Installing </source>
        <translation>Установка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2968"/>
        <source>Post-processing for </source>
        <translation>Обработка для</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3184"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Произошла ошибка при загрузке или записи файла: %1. Пожалуйста, проверьте подключение к Интернету и свободное место на диске.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3277"/>
        <source>Downloading package info...</source>
        <translation>Загрузка информации о пакетах...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3917"/>
        <location filename="../src/mainwindow.cpp" line="4064"/>
        <location filename="../src/mainwindow.cpp" line="4215"/>
        <location filename="../src/mainwindow.cpp" line="4259"/>
        <source>Package info</source>
        <translation>Информация о пакете</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3953"/>
        <location filename="../src/mainwindow.cpp" line="5871"/>
        <source>More &amp;info...</source>
        <translation>Подро&amp;бности...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4164"/>
        <source>Packages to be installed: </source>
        <translation>Пакеты, которые будут установлены:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4451"/>
        <location filename="../src/mainwindow.cpp" line="4508"/>
        <location filename="../src/mainwindow.cpp" line="4530"/>
        <location filename="../src/mainwindow.cpp" line="4695"/>
        <location filename="../src/mainwindow.cpp" line="4741"/>
        <location filename="../src/mainwindow.cpp" line="5661"/>
        <location filename="../src/mainwindow.cpp" line="5792"/>
        <location filename="../src/mainwindow.cpp" line="5825"/>
        <location filename="../src/mainwindow.cpp" line="5934"/>
        <location filename="../src/mainwindow_snap.cpp" line="500"/>
        <source>Done</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4451"/>
        <location filename="../src/mainwindow.cpp" line="4508"/>
        <location filename="../src/mainwindow.cpp" line="4530"/>
        <location filename="../src/mainwindow.cpp" line="4695"/>
        <location filename="../src/mainwindow.cpp" line="4741"/>
        <location filename="../src/mainwindow.cpp" line="4759"/>
        <location filename="../src/mainwindow.cpp" line="5661"/>
        <location filename="../src/mainwindow.cpp" line="5792"/>
        <location filename="../src/mainwindow.cpp" line="5825"/>
        <location filename="../src/mainwindow.cpp" line="5934"/>
        <location filename="../src/mainwindow.cpp" line="5984"/>
        <location filename="../src/mainwindow_snap.cpp" line="500"/>
        <source>Processing finished successfully.</source>
        <translation>Обработка успешно завершена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <location filename="../src/mainwindow.cpp" line="4506"/>
        <location filename="../src/mainwindow.cpp" line="5820"/>
        <source>Install complete.</source>
        <translation>Установка завершена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="539"/>
        <location filename="../src/mainwindow.cpp" line="3696"/>
        <location filename="../src/mainwindow.cpp" line="3804"/>
        <source>The installed-package query returned an error. Please check the log for details.</source>
        <translation>Запрос к установленным пакетам вернул ошибку. Пожалуйста, проверьте журнал для получения подробной информации.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1724"/>
        <source>Show/hide input</source>
        <translation>Показать/скрыть ввод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1729"/>
        <source>Clear input</source>
        <translation>Очистить ввод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2535"/>
        <source>You are about to use the AUR, which contains user-contributed packages. These packages are not vetted by the distribution, may be outdated, and could contain malicious or broken build scripts. Use with care.</source>
        <translation>Вы собираетесь использовать AUR, который содержит пакеты, созданные пользователями. Эти пакеты не проверяются дистрибутивом, могут быть устаревшими и могут содержать вредоносные или неработающие сценарии сборки. Используйте с осторожностью.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>paru is not installed.

To install AUR packages, please install paru first:
pacman -S paru

Then try installing the AUR package again.</source>
        <translation>paru не установлен.

Для установки пакетов AUR сначала установите paru:
pacman -S paru

Затем попробуйте установить пакет AUR снова.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2813"/>
        <source>AUR packages cannot be built as root, and no regular user could be found to build as.

Install the package as your normal user instead.</source>
        <translation>Пакеты AUR не могут быть собраны от имени root, и не удалось найти обычного пользователя для сборки.

Установите пакет от имени обычного пользователя.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3183"/>
        <source>The download timed out. Please check your internet connection and try again.</source>
        <translation>Время загрузки истекло. Пожалуйста, проверьте подключение к Интернету и попробуйте снова.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4047"/>
        <source>Developer: %1</source>
        <translation>Разработчик: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4050"/>
        <source>License: %1</source>
        <translation>Лицензия: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4054"/>
        <source>Homepage: %1</source>
        <translation>Домашняя страница: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4148"/>
        <location filename="../src/mainwindow.cpp" line="4216"/>
        <location filename="../src/mainwindow_snap.cpp" line="575"/>
        <location filename="../src/mainwindow_aur.cpp" line="163"/>
        <source>No information available.</source>
        <translation>Информация отсутствует.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4456"/>
        <location filename="../src/mainwindow.cpp" line="4534"/>
        <location filename="../src/mainwindow.cpp" line="5665"/>
        <location filename="../src/mainwindow.cpp" line="5797"/>
        <location filename="../src/mainwindow.cpp" line="5832"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Обнаружена проблема при установке, пожалуйста, проверьте вывод консоли.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4475"/>
        <source>Install snaps</source>
        <translation>Установить пакеты Snap</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4476"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation>Установить следующие пакеты Snap?

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4487"/>
        <source>Installing packages: %1...</source>
        <translation>Установка пакетов: %1…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4490"/>
        <source>Installing package: %1...</source>
        <translation>Установка пакета: %1…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4511"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation>Обнаружена проблема при установке пакета Snap. Нажмите «Показать подробности» для получения дополнительной информации.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4546"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4547"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <source>Package Installer for MX Linux</source>
        <translation>Установщик пакетов для MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4551"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4552"/>
        <source>%1 License</source>
        <translation>Лицензия %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4560"/>
        <location filename="../src/mainwindow.cpp" line="4562"/>
        <source>%1 Help</source>
        <translation>Справка %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4676"/>
        <location filename="../src/mainwindow.cpp" line="5927"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Удаление пакетов Flatpak...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4685"/>
        <location filename="../src/mainwindow.cpp" line="4739"/>
        <location filename="../src/mainwindow.cpp" line="5929"/>
        <source>Uninstall complete.</source>
        <translation>Удаление завершено.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4686"/>
        <location filename="../src/mainwindow.cpp" line="5930"/>
        <source>Refreshing flatpaks...</source>
        <translation>Обновление списка Flatpak...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4699"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>При удалении возникла проблема, пожалуйста, проверьте вывод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4719"/>
        <source>Remove snaps</source>
        <translation>Удалить пакеты Snap</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4720"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation>Удалить следующие пакеты Snap?

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4744"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation>При удалении пакета Snap возникла проблема. Нажмите «Показать подробности» для получения дополнительной информации.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4759"/>
        <location filename="../src/mainwindow.cpp" line="5984"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4762"/>
        <location filename="../src/mainwindow.cpp" line="5987"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>При удалении программы возникла проблема</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3327"/>
        <location filename="../src/mainwindow.cpp" line="4948"/>
        <location filename="../src/mainwindow.cpp" line="5000"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Не удалось загрузить список пакетов. Пожалуйста, проверьте ваши источники APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="154"/>
        <source>paru is not installed.

Install it with: pacman -S paru</source>
        <translation>paru не установлен.

Установите его с помощью: pacman -S paru</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="186"/>
        <source>Could not query AUR packages. Please check that paru is installed and you are online.</source>
        <translation>Не удалось выполнить запрос к пакетам AUR. Пожалуйста, проверьте, установлен ли paru и есть ли подключение к Интернету.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5082"/>
        <location filename="../src/mainwindow.cpp" line="5140"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak не установлен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5083"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>В настоящий момент Flatpak не установлен.
Установить его?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5140"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak не был установлен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5167"/>
        <location filename="../src/mainwindow_snap.cpp" line="479"/>
        <source>Needs re-login</source>
        <translation>Требуется повторный вход</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5168"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Возможно, потребуется выйти и снова войти в систему, чтобы увидеть установленные элементы в меню</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No results</source>
        <translation>Нет результатов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation>Не найдено пакетов Snap, соответствующих &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="368"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation>snapd не был установлен. Нажмите «Показать подробности» для получения дополнительной информации.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="400"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation>Установка базового пакета Snap &quot;core&quot;...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="466"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation>Вывод не был захвачен. Выполните &apos;sudo snap install core&apos; в терминале, чтобы увидеть основную ошибку.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="471"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation>snapd был установлен, но его служба не может быть запущена. Возможно, потребуется перезагрузить систему или выйти и снова войти в систему, затем снова открыть вкладку Snap. Нажмите «Показать подробности» для получения дополнительной информации.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="475"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation>Поддержка Snap была включена, но базовый пакет Snap &quot;core&quot; не может быть установлен, поэтому большинство пакетов Snap пока не будут работать. Нажмите «Показать подробности» для получения основной ошибки.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="505"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation>Обнаружена проблема при обновлении пакетов Snap. Нажмите «Показать подробности» для получения дополнительной информации.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5362"/>
        <location filename="../src/mainwindow.cpp" line="5373"/>
        <location filename="../src/mainwindow.cpp" line="5451"/>
        <location filename="../src/mainwindow.cpp" line="5514"/>
        <source>Mark keep</source>
        <translation>Оставить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5395"/>
        <source>Select/deselect all upgradable</source>
        <translation>Выбрать/отменить выбор всех обновляемых</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5396"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Выбрать/отменить выбор всех автоудаляемых</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5453"/>
        <location filename="../src/mainwindow.cpp" line="5512"/>
        <source>Upgrade</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5717"/>
        <source>Show input</source>
        <translation>Показать ввод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5717"/>
        <source>Hide input</source>
        <translation>Скрыть ввод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5726"/>
        <location filename="../src/mainwindow.cpp" line="5882"/>
        <source>Quit?</source>
        <translation>Выйти?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5727"/>
        <location filename="../src/mainwindow.cpp" line="5883"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Процесс всё ещё выполняется, выход может оставить систему в нестабильном состоянии.&lt;p&gt;&lt;b&gt;Вы уверены, что хотите выйти из MX Установщика пакетов?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5492"/>
        <source>Reinstall</source>
        <translation>Переустановить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="480"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation>Выйдите и снова войдите в систему, чтобы увидеть установленные элементы в меню и использовать команды Snap из /snap/bin. Эти изменения не применяются к текущему сеансу.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5789"/>
        <location filename="../src/mainwindow_snap.cpp" line="497"/>
        <source>Update complete.</source>
        <translation>Обновление завершено.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5611"/>
        <location filename="../src/mainwindow.cpp" line="5939"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Обнаружена проблема во время последней операции, пожалуйста, проверьте вывод консоли.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5978"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Потенциально опасная операция.
Пожалуйста, внимательно проверьте список удаляемых пакетов.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Управление внешними репозиториями Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Для всех пользователей</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Для текущего пользователя</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>введите URL внешнего репозитория Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>введите местоположение .flatpakref для установки приложения</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Добавить или удалить внешние репозитории Flatpak, или установить приложения, используя URL или путь к .flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Удалить внешний репозиторий</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Добавить внешний репозиторий</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Установить приложение</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="85"/>
        <source>Not removable</source>
        <translation>Неудаляемый</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="86"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub является основным внешним репозиторием Flatpak и не может быть удалён</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="104"/>
        <source>Error removing remote</source>
        <translation>Ошибка при удалении внешнего репозитория</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Could not remove remote - command returned an error. Please try again.</source>
        <translation>Не удалось удалить внешний репозиторий — команда вернула ошибку. Пожалуйста, попробуйте снова.</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="122"/>
        <source>Error adding remote</source>
        <translation>Ошибка при добавлении внешнего репозитория</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="123"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Не удалось добавить внешний репозиторий — команда вернула ошибку. Пожалуйста, проверьте адрес внешнего репозитория и попробуйте снова</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Remote added successfully</source>
        <translation>Внешний репозиторий успешно добавлен</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="148"/>
        <source>Repo Version</source>
        <translation>Версия в репозитории</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="150"/>
        <source>Installed</source>
        <translation>Установлено</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="152"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Категория</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <location filename="../src/about.cpp" line="113"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="123"/>
        <source>Could not load changelog.</source>
        <translation>Не удалось загрузить список изменений.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="126"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="69"/>
        <location filename="../src/lockfile_apt.cpp" line="52"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="89"/>
        <source>no running process (stale lock file %1)</source>
        <translation>нет запущенного процесса (устаревший файл блокировки %1)</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="53"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>База данных Dpkg/apt заблокирована другой программой: %1
Закройте программу или подождите, пока она завершит обработку, и попробуйте снова.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="87"/>
        <source>another package manager</source>
        <translation>другой менеджер пакетов</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Установщик пакетов — это инструмент для управления пакетами в MX Linux
    - установка популярных программ из разных источников
    - установка программ из тестового репозитория MX
    - установка программ из репозитория Debian Backports
    - установка Flatpak</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Пропустить проверку подключения к Интернету, если она ложно сообщает об его отсутствии.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <location filename="../src/main.cpp" line="120"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Похоже, вы вошли в систему как root. Пожалуйста, выйдите и войдите как обычный пользователь для использования этой программы.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="121"/>
        <source>You must run this program with admin access.</source>
        <translation>Вы должны запустить эту программу с правами администратора.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="70"/>
        <source>Pacman database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>База данных Pacman заблокирована другой программой: %1
Закройте программу или подождите, пока она завершит обработку, и попробуйте снова.</translation>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="89"/>
        <source>More info</source>
        <translation>Подробности</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="157"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="161"/>
        <source>Publisher</source>
        <translation>Издатель</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="163"/>
        <source>Notes</source>
        <translation>Заметки</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="165"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
</TS>