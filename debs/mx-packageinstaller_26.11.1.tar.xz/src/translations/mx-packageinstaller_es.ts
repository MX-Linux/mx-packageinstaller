<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="534"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="535"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation>Esta operación requiere privilegios de administrador. Intente realizar la acción de nuevo e introduzca su contraseña cuando se le solicite.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="93"/>
        <source>More info</source>
        <translation>Más información</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="167"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="169"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="171"/>
        <source>Full Name</source>
        <translation>Nombre completo</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="173"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="175"/>
        <source>Branch</source>
        <translation>Rama</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>MX Package Installer</source>
        <translation>MX Instalador de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Aplicaciones populares</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Gestionar paquetes populares&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="964"/>
        <location filename="../src/mainwindow.ui" line="1355"/>
        <location filename="../src/mainwindow.ui" line="1476"/>
        <location filename="../src/mainwindow.ui" line="1864"/>
        <source>search</source>
        <translation>buscar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="669"/>
        <location filename="../src/mainwindow.ui" line="989"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>= Installed packages</source>
        <translation>= Paquetes instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Repositorios habilitados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Elimina todos los paquetes marcados como &amp;quot;autoremovible&amp;quot;. Si desea gestionarlos, seleccione Autoremovible en el cuadro de selección desplegable.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Paquetes autoremovibles</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1552"/>
        <source>Upgrade All</source>
        <translation>Actualizar Todos:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="808"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>Installed:</source>
        <translation>Instalado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="801"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Total packages:</source>
        <translation>Paquetes totales:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <location filename="../src/mainwindow.ui" line="1260"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Instalar también los paquetes &quot;Recomendados&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="838"/>
        <location filename="../src/mainwindow.ui" line="1185"/>
        <source>Upgradable:</source>
        <translation>Actualizable:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1220"/>
        <source>Hide library and developer packages</source>
        <translation>Ocultar paquetes de bibliotecas y desarrolladores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="600"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <location filename="../src/mainwindow.ui" line="1279"/>
        <location filename="../src/mainwindow.ui" line="1764"/>
        <location filename="../src/mainwindow.ui" line="1874"/>
        <source>Refresh list</source>
        <translation>Recargar lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="728"/>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <location filename="../src/mainwindow.ui" line="1816"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrar paquetes según su estado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="735"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <location filename="../src/mainwindow.ui" line="1058"/>
        <location filename="../src/mainwindow.ui" line="1388"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.cpp" line="5392"/>
        <source>All packages</source>
        <translation>Todos los paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="740"/>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.ui" line="1397"/>
        <location filename="../src/mainwindow.cpp" line="5418"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="5419"/>
        <source>Upgradable</source>
        <translation>Actualizable</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1073"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.ui" line="1756"/>
        <location filename="../src/mainwindow.cpp" line="5385"/>
        <location filename="../src/mainwindow.cpp" line="5420"/>
        <source>Not installed</source>
        <translation>No instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.ui" line="1078"/>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <location filename="../src/mainwindow.cpp" line="2144"/>
        <location filename="../src/mainwindow.cpp" line="5356"/>
        <location filename="../src/mainwindow.cpp" line="5421"/>
        <location filename="../src/mainwindow.cpp" line="5481"/>
        <source>Autoremovable</source>
        <translation>Autoremovible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <location filename="../src/mainwindow.ui" line="1020"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Paquete actualizable. Versión más reciente disponible en el repositorio seleccionado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>MX Test Repo</source>
        <translation>MX Repo de prueba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Debian Backports</source>
        <translation>Backports de Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1687"/>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>For all users</source>
        <translation>Para todos los usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1696"/>
        <source>For current user</source>
        <translation>Para el usuario actual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1781"/>
        <source>Remote (repo):</source>
        <translation>Repositorio:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1722"/>
        <location filename="../src/mainwindow.ui" line="1726"/>
        <location filename="../src/mainwindow.cpp" line="5367"/>
        <source>All apps</source>
        <translation>Todas las apps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1731"/>
        <location filename="../src/mainwindow.cpp" line="5373"/>
        <source>All runtimes</source>
        <translation>Todos los binarios de ejecución</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1736"/>
        <location filename="../src/mainwindow.cpp" line="5379"/>
        <source>All available</source>
        <translation>Todos disponibles</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1741"/>
        <location filename="../src/mainwindow.cpp" line="5364"/>
        <source>Installed apps</source>
        <translation>Apps instaladas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1746"/>
        <location filename="../src/mainwindow.cpp" line="5361"/>
        <source>Installed runtimes</source>
        <translation>Binarios de ejecución instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1751"/>
        <location filename="../src/mainwindow.cpp" line="5383"/>
        <source>All installed</source>
        <translation>Todos los instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1531"/>
        <location filename="../src/mainwindow.ui" line="1941"/>
        <source>Total items </source>
        <translation>Total de elementos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1545"/>
        <source>Installed apps:</source>
        <translation>Apps instaladas:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1597"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1626"/>
        <source>Total installed size:</source>
        <translation>Tamaño total instalado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1640"/>
        <source>Remove unused runtimes</source>
        <translation>Eliminar los tiempos de ejecución no usados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="613"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>AUR</source>
        <translation>AUR</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="656"/>
        <source>search AUR (type to find more)</source>
        <translation>Buscar en AUR (escriba para encontrar más)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="763"/>
        <source>Tip: search to find other AUR packages. Installed AUR packages are shown when the search box is empty.</source>
        <translation>Consejo: utilice la búsqueda para encontrar otros paquetes de AUR. Los paquetes de AUR instalados se muestran cuando el cuadro de búsqueda está vacío.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <location filename="../src/mainwindow.ui" line="1230"/>
        <source>Only repo packages</source>
        <translation>Solo paquetes de repositorio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1798"/>
        <source>Snaps</source>
        <translation>Snaps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1819"/>
        <location filename="../src/mainwindow.ui" line="1823"/>
        <location filename="../src/mainwindow_snap.cpp" line="234"/>
        <location filename="../src/mainwindow_snap.cpp" line="313"/>
        <source>Installed snaps</source>
        <translation>Snaps instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1828"/>
        <location filename="../src/mainwindow.cpp" line="5250"/>
        <location filename="../src/mainwindow_snap.cpp" line="149"/>
        <location filename="../src/mainwindow_snap.cpp" line="237"/>
        <location filename="../src/mainwindow_snap.cpp" line="239"/>
        <source>Search store</source>
        <translation>Buscar en la tienda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1861"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Escriba un término y pulse Intro para buscar en la tienda de aplicaciones.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1893"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation>El soporte para Snap no está configurado en este sistema. Haga clic en el botón para instalar snapd y habilitar el servicio Snap.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1903"/>
        <source>Set up Snap support</source>
        <translation>Configurar la compatibilidad con Snap</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1955"/>
        <source>Installed snaps:</source>
        <translation>Snaps instalados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1982"/>
        <source>Update All</source>
        <translation>Actualizar todo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2005"/>
        <location filename="../src/mainwindow.cpp" line="4813"/>
        <location filename="../src/mainwindow.cpp" line="5206"/>
        <source>Console Output</source>
        <translation>Salida en consola</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2011"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2021"/>
        <source>Respond here, or just press Enter</source>
        <translation>Responda aquí, o sólo presione Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2080"/>
        <location filename="../src/mainwindow.cpp" line="2736"/>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <location filename="../src/mainwindow_snap.cpp" line="295"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2086"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2105"/>
        <source>Quit application</source>
        <translation>Terminar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2108"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2114"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2146"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2149"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2155"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2193"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2196"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2202"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2218"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2224"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1040"/>
        <source>Uninstalling packages...</source>
        <translation>Desinstalando paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1045"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Ejecutando las operaciones de predesinstalación...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1063"/>
        <source>Running post-uninstall operations...</source>
        <translation>Ejecutando operaciones de post-desinstalación....</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1080"/>
        <source>Refreshing sources...</source>
        <translation>Recargando fuentes.. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <location filename="../src/mainwindow.cpp" line="1093"/>
        <location filename="../src/mainwindow.cpp" line="2789"/>
        <location filename="../src/mainwindow.cpp" line="2821"/>
        <location filename="../src/mainwindow.cpp" line="2844"/>
        <location filename="../src/mainwindow.cpp" line="3013"/>
        <location filename="../src/mainwindow.cpp" line="3213"/>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <location filename="../src/mainwindow.cpp" line="3353"/>
        <location filename="../src/mainwindow.cpp" line="3729"/>
        <location filename="../src/mainwindow.cpp" line="3843"/>
        <location filename="../src/mainwindow.cpp" line="4496"/>
        <location filename="../src/mainwindow.cpp" line="4574"/>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="4991"/>
        <location filename="../src/mainwindow.cpp" line="5043"/>
        <location filename="../src/mainwindow.cpp" line="5653"/>
        <location filename="../src/mainwindow.cpp" line="5707"/>
        <location filename="../src/mainwindow.cpp" line="5839"/>
        <location filename="../src/mainwindow.cpp" line="5874"/>
        <location filename="../src/mainwindow.cpp" line="5981"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <location filename="../src/mainwindow_snap.cpp" line="33"/>
        <location filename="../src/mainwindow_aur.cpp" line="154"/>
        <location filename="../src/mainwindow_aur.cpp" line="186"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1094"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Hubo problemas al recargar las fuentes. Algunas fuentes parecen no tener actualizaciones. Para más información, revise:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1229"/>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>No se pudo determinar la versión de Debian. Seleccione la suya:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1262"/>
        <source>Debian Version</source>
        <translation>Versión de Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1795"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1801"/>
        <source>Please wait...</source>
        <translation>Por favor, espere...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2525"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Está a punto de utilizar el repositorio MX de prueba, cuyos paquetes se proporcionan solo con fines de prueba. Podrían llegar a dañar su sistema, por lo que se sugiere que haga un respaldo de su sistema e instale y/o actualice solo un paquete a la vez. Por favor, envíe sus comentarios al Foro para que los paquetes puedan ser evaluados antes de pasar al repositorio principal (Main) </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2534"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Va a usar Debian Backports, que contiene paquetes tomados de la próxima versión de Debian (llamada &apos;prueba&apos;), ajustados y recompilados para el uso en Debian Estable. Los mismos no pueden ser probados extensivamente como en las versiones estables de Debian y MX Linux, y se proporcionan &apos;como están&apos;, con el riesgo de incompatibilidades con otros componentes en Debian Estable. ¡Utilícelos con cuidado!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2542"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux incluye este repositorio de flatpaks solo para la conveniencia de los usuarios, y no es responsable de la funcionalidad de los flatpaks individuales. Para más información, consulte flatpaks en la Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2558"/>
        <location filename="../src/mainwindow.cpp" line="6020"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2560"/>
        <source>Do not show this message again</source>
        <translation>No mostrar este mensaje de nuevo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2733"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2624"/>
        <location filename="../src/mainwindow.cpp" line="2749"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Se han seleccionado los siguientes paquetes. Haga clic en Mostrar detalles para ver la lista de cambios.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="3014"/>
        <location filename="../src/mainwindow.cpp" line="3296"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet no esta disponible, no puede descargar la lista de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>Installing packages...</source>
        <translation>Instalando paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2936"/>
        <source>Post-processing...</source>
        <translation>Post-procesamiento...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2975"/>
        <source>Pre-processing for </source>
        <translation>Pre-procesamiento para </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2985"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2997"/>
        <source>Post-processing for </source>
        <translation>Post-procesamiento para </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3210"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Hubo un error al escribir el archivo: %1. Por favor, compruebe si tiene suficiente espacio libre en su disco</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3303"/>
        <source>Downloading package info...</source>
        <translation>Bajando info de paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <location filename="../src/mainwindow.cpp" line="4104"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4300"/>
        <source>Package info</source>
        <translation>Info de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3993"/>
        <location filename="../src/mainwindow.cpp" line="5914"/>
        <source>More &amp;info...</source>
        <translation>Más &amp;información...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4204"/>
        <source>Packages to be installed: </source>
        <translation>Paquetes a instalar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Done</source>
        <translation>Listo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Processing finished successfully.</source>
        <translation>Procesamiento completado con éxito. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4487"/>
        <location filename="../src/mainwindow.cpp" line="4547"/>
        <location filename="../src/mainwindow.cpp" line="5863"/>
        <source>Install complete.</source>
        <translation>Instalación completada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <location filename="../src/mainwindow.cpp" line="3730"/>
        <location filename="../src/mainwindow.cpp" line="3844"/>
        <source>The installed-package query returned an error. Please check the log for details.</source>
        <translation>La consulta sobre los paquetes instalados ha devuelto un error. Consulte el registro para obtener más detalles.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Show/hide input</source>
        <translation>Mostrar/ocultar entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>Clear input</source>
        <translation>Borrar entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2549"/>
        <source>You are about to use the AUR, which contains user-contributed packages. These packages are not vetted by the distribution, may be outdated, and could contain malicious or broken build scripts. Use with care.</source>
        <translation>Está a punto de utilizar AUR, que contiene paquetes aportados por los usuarios. Estos paquetes no han sido revisados por la distribución, pueden estar desactualizados y podrían contener scripts de compilación maliciosos o defectuosos. Úselos con precaución.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2628"/>
        <source>Pacman will also perform a full system upgrade.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2822"/>
        <source>paru is not installed.

To install AUR packages, please install paru first:
pacman -S paru

Then try installing the AUR package again.</source>
        <translation>paru no está instalado.

Para instalar paquetes de AUR, instala primero paru:
pacman -S paru

A continuación, intente instalar de nuevo el paquete de AUR.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2845"/>
        <source>AUR packages cannot be built as root, and no regular user could be found to build as.

Install the package as your normal user instead.</source>
        <translation>Los paquetes AUR no se pueden compilar como root, y no se ha encontrado ningún usuario normal con el que poder compilarlos.

Instale el paquete como su usuario habitual.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3209"/>
        <source>The download timed out. Please check your internet connection and try again.</source>
        <translation>Se agotó el tiempo de espera de la descarga. Compruebe su conexión a Internet e inténtelo de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4087"/>
        <source>Developer: %1</source>
        <translation>Desarrollador: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4090"/>
        <source>License: %1</source>
        <translation>Licencia: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4094"/>
        <source>Homepage: %1</source>
        <translation>Página web: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4188"/>
        <location filename="../src/mainwindow.cpp" line="4257"/>
        <location filename="../src/mainwindow_snap.cpp" line="574"/>
        <location filename="../src/mainwindow_aur.cpp" line="164"/>
        <source>No information available.</source>
        <translation>No hay información disponible.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4497"/>
        <location filename="../src/mainwindow.cpp" line="4575"/>
        <location filename="../src/mainwindow.cpp" line="5708"/>
        <location filename="../src/mainwindow.cpp" line="5840"/>
        <location filename="../src/mainwindow.cpp" line="5875"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Problemas detectadso durante la instalación; favor inspeccionar la salida en consola.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4516"/>
        <source>Install snaps</source>
        <translation>Instalar snaps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4517"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation>¿Quiere instalar los siguientes paquetes snap?

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4528"/>
        <source>Installing packages: %1...</source>
        <translation>Instalando paquetes: %1...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4531"/>
        <source>Installing package: %1...</source>
        <translation>Instalando paquetes: %1...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4552"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation>Se ha detectado un problema al instalar un snap. Haga clic en &quot;Mostrar detalles” para obtener más información.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4587"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4588"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4590"/>
        <source>Package Installer for MX Linux</source>
        <translation>Instalador de paquetes para MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4592"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4593"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4601"/>
        <location filename="../src/mainwindow.cpp" line="4603"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <location filename="../src/mainwindow.cpp" line="5970"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Desinstalando paquetes flatpaks...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4726"/>
        <location filename="../src/mainwindow.cpp" line="4780"/>
        <location filename="../src/mainwindow.cpp" line="5972"/>
        <source>Uninstall complete.</source>
        <translation>Desinstalación completada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4727"/>
        <location filename="../src/mainwindow.cpp" line="5973"/>
        <source>Refreshing flatpaks...</source>
        <translation>Recargando flatpaks...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Hubo un problema desinstalando; favor revisae la salida.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4760"/>
        <source>Remove snaps</source>
        <translation>Eliminar snaps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4761"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation>¿Quiere eliminar los siguientes paquetes Snap?

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4785"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation>Hemos tenido un problema al eliminar un snap. Haga clic en &quot;Mostrar detalles&quot; para obtener más información.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <source>Success</source>
        <translation>Éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Hubo un problema durante la desinstalación del programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3354"/>
        <location filename="../src/mainwindow.cpp" line="4992"/>
        <location filename="../src/mainwindow.cpp" line="5044"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>No se ha podido descargar la lista de paquetes. Por favor, compruebe sus fuentes APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="155"/>
        <source>paru is not installed.

Install it with: pacman -S paru</source>
        <translation>paru no está instalado.

Instálelo con: pacman -S paru</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="187"/>
        <source>Could not query AUR packages. Please check that paru is installed and you are online.</source>
        <translation>No se pudieron consultar los paquetes de AUR. Compruebe que paru esté instalado y que tenga conexión a Internet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5126"/>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak no esta instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5127"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak no está instalado.
¿Está bien continuarr e instalarlo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak no fue instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <location filename="../src/mainwindow_snap.cpp" line="478"/>
        <source>Needs re-login</source>
        <translation>Necesita re-login</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5211"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Quizás necesite cerrar/iniciar sesión para ver en el menú los elementos instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No results</source>
        <translation>Sin resultados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation>No se encontraron snaps que coincidieran con&quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="367"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation>snapd no está instalado. Haga clic en &quot;Mostrar detalles” para obtener más información.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="399"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation>Instalando la base &quot;core&quot; de Snap...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="465"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation>No se ha registrado ninguna salida. Ejecute &quot;sudo snap install core&quot; en una terminal para ver el error subyacente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="470"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation>Se ha instalado snapd, pero no se ha podido iniciar su servicio. Es posible que tenga que reiniciar el equipo o cerrar sesión y volver a iniciarla, y luego volver a abrir la pestaña &quot;Snap&quot;. Haga clic en &quot;Mostrar detalles&quot; para obtener más información.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="474"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation>La compatibilidad con Snap estaba habilitada, pero no se pudo instalar el &quot;core&quot; base de snap, por lo que la mayoría de los snaps aún no funcionarán. Haga clic en &quot;Mostrar detalles” para ver el error subyacente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="504"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation>Se ha detectado un problema al actualizar los snaps. Haga clic en &quot;Mostrar detalles” para obtener más información.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5494"/>
        <location filename="../src/mainwindow.cpp" line="5557"/>
        <source>Mark keep</source>
        <translation>Marcar para conservar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5438"/>
        <source>Select/deselect all upgradable</source>
        <translation>Seleccionar/deseleccionar todo lo actualizable</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5439"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Seleccionar/deseccionar todo lo autoremovible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <source>Upgrade</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Show input</source>
        <translation>Mostrar entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Hide input</source>
        <translation>Ocultar entrada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5769"/>
        <location filename="../src/mainwindow.cpp" line="5925"/>
        <source>Quit?</source>
        <translation>¿Salir?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5770"/>
        <location filename="../src/mainwindow.cpp" line="5926"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>El proceso todavía se está ejecutando, salir puede causar inestabilidad en el sistema.&lt;p&gt;&lt;b&gt;¿Está seguro de que desea salir de MX Instalador de paquetes?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <source>Reinstall</source>
        <translation>Reinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="479"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation>Cierre la sesión y vuelva a iniciarla para ver los elementos instalados en el menú y utilizar los comandos de snap desde /snap/bin. Estos cambios no se aplican a la sesión actual.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5832"/>
        <location filename="../src/mainwindow_snap.cpp" line="496"/>
        <source>Update complete.</source>
        <translation>Actualización completada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5654"/>
        <location filename="../src/mainwindow.cpp" line="5982"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Problema detectado durante la última operación, por favor inspeccione la salida de la consola.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="6021"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Operación potencialmente peligrosa.
Por favor, asegúrese de comprobar cuidadosamente la lista de paquetes que deben ser eliminados.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Gestionar repositorios remotos de Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Para todos los usuarios</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Para el usuario actual</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>ingresar la URL remota de Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>ingresar la ubicación de Flatpakref para instalar el app</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Añada o elimine repositorios remotos de flatpak, o instale aplicaciones usando la URL o ruta de flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Eliminar el repositorio</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Añadir el repositorio</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Instalar la app</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="85"/>
        <source>Not removable</source>
        <translation>No es removible</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="86"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub es el repositorio remoto principal de Flatpak y no se eliminará</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="104"/>
        <source>Error removing remote</source>
        <translation>Error eliminando el repositorio</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Could not remove remote - command returned an error. Please try again.</source>
        <translation>No se pudo eliminar el repositorio: el comando ha devuelto un error. Inténtelo de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="122"/>
        <source>Error adding remote</source>
        <translation>Error añadiendo el repositorio</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="123"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>No se pudo añadir el repositorio: el comando devolvió un error. Compruebe la dirección remota e inténtelo de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Success</source>
        <translation>Exito</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Remote added successfully</source>
        <translation>Repositorio añadido con éxito</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="148"/>
        <source>Repo Version</source>
        <translation>Versión del Repositorio</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="150"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="152"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <location filename="../src/about.cpp" line="113"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="123"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="126"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="69"/>
        <location filename="../src/lockfile_apt.cpp" line="52"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="89"/>
        <source>no running process (stale lock file %1)</source>
        <translation>ningún proceso en ejecución (archivo de bloqueo obsoleto %1)</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="53"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>La base de datos dpkg/apt está bloqueada por otro programa: %1
Cierre el programa o espere a que termine el proceso e inténtelo de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="87"/>
        <source>another package manager</source>
        <translation>otro gestor de paquetes</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Instalador de Paquetes es una herramienta utilizada para la gestión de paquetes en MX Linux
    - instala programas populares de diferentes fuentes
    - instala programas del repositorio MX Test
    - instala programas del repositorio Debian Backports
    - instala flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Omitir la comprobación en línea si informa falsamente de la falta de acceso a Internet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <location filename="../src/main.cpp" line="130"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>You must run this program with admin access.</source>
        <translation>Debe ejecutar este programa con acceso de administrador.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="70"/>
        <source>Pacman database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>PLa base de datos de Pacman está bloqueada por otro programa: %1 
Cierre el programa o espere a que termine el proceso y vuelva a intentarlo.</translation>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="89"/>
        <source>More info</source>
        <translation>Más información</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="157"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="161"/>
        <source>Publisher</source>
        <translation>Editor</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="163"/>
        <source>Notes</source>
        <translation>Notas</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="165"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
</context>
</TS>