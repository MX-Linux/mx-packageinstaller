<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nb">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="534"/>
        <source>Administrator Access Required</source>
        <translation>Administratortilgang kreves</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="535"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="93"/>
        <source>More info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="167"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="169"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="171"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="173"/>
        <source>Version</source>
        <translation>Versjon</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="175"/>
        <source>Branch</source>
        <translation>Gren</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>MX Package Installer</source>
        <translation>MX Verktøy for pakkeinstallering</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Populære programmer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Behandle populære pakker&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="964"/>
        <location filename="../src/mainwindow.ui" line="1355"/>
        <location filename="../src/mainwindow.ui" line="1476"/>
        <location filename="../src/mainwindow.ui" line="1864"/>
        <source>search</source>
        <translation>søk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="669"/>
        <location filename="../src/mainwindow.ui" line="989"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>= Installed packages</source>
        <translation>= Installerte pakker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Aktive pakkearkiv</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Fjern alle pakkene som er markert som &amp;quot;kan autofjernes&amp;quot;. Velg &apos;Kan autofjernes&apos; fra nedtrekksmenyen hvis du vil behandle dem.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Pakker som kan autofjernes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1552"/>
        <source>Upgrade All</source>
        <translation>Oppgrader alle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="808"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>Installed:</source>
        <translation>Installerte:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="801"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Total packages:</source>
        <translation>Antall pakker:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <location filename="../src/mainwindow.ui" line="1260"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Installer også anbefalte pakker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="838"/>
        <location filename="../src/mainwindow.ui" line="1185"/>
        <source>Upgradable:</source>
        <translation>Kan oppgraderes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1220"/>
        <source>Hide library and developer packages</source>
        <translation>Skjul bibliotek- og utviklerpakker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="600"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <location filename="../src/mainwindow.ui" line="1279"/>
        <location filename="../src/mainwindow.ui" line="1764"/>
        <location filename="../src/mainwindow.ui" line="1874"/>
        <source>Refresh list</source>
        <translation>Oppdater liste</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="728"/>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <location filename="../src/mainwindow.ui" line="1816"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrer pakker i henhold til deres status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="735"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <location filename="../src/mainwindow.ui" line="1058"/>
        <location filename="../src/mainwindow.ui" line="1388"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.cpp" line="5392"/>
        <source>All packages</source>
        <translation>Alle pakker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="740"/>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.ui" line="1397"/>
        <location filename="../src/mainwindow.cpp" line="5418"/>
        <source>Installed</source>
        <translation>Installert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="5419"/>
        <source>Upgradable</source>
        <translation>Kan oppgraderes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1073"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.ui" line="1756"/>
        <location filename="../src/mainwindow.cpp" line="5385"/>
        <location filename="../src/mainwindow.cpp" line="5420"/>
        <source>Not installed</source>
        <translation>Ikke installert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.ui" line="1078"/>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <location filename="../src/mainwindow.cpp" line="2144"/>
        <location filename="../src/mainwindow.cpp" line="5356"/>
        <location filename="../src/mainwindow.cpp" line="5421"/>
        <location filename="../src/mainwindow.cpp" line="5481"/>
        <source>Autoremovable</source>
        <translation>Kan autofjernes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <location filename="../src/mainwindow.ui" line="1020"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Pakke som kan oppgraderes. Nyere versjon er tilgjengelig i valgt pakkearkiv.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>MX Test Repo</source>
        <translation>MX Test-pakkearkiv</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1687"/>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>For all users</source>
        <translation>For alle brukere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1696"/>
        <source>For current user</source>
        <translation>For gjeldende bruker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1781"/>
        <source>Remote (repo):</source>
        <translation>Ekstern (pakkearkiv):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1722"/>
        <location filename="../src/mainwindow.ui" line="1726"/>
        <location filename="../src/mainwindow.cpp" line="5367"/>
        <source>All apps</source>
        <translation>Alle programmer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1731"/>
        <location filename="../src/mainwindow.cpp" line="5373"/>
        <source>All runtimes</source>
        <translation>Alle kjøremiljø</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1736"/>
        <location filename="../src/mainwindow.cpp" line="5379"/>
        <source>All available</source>
        <translation>Alle tilgjengelige</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1741"/>
        <location filename="../src/mainwindow.cpp" line="5364"/>
        <source>Installed apps</source>
        <translation>Installerte programmer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1746"/>
        <location filename="../src/mainwindow.cpp" line="5361"/>
        <source>Installed runtimes</source>
        <translation>Installerte kjøremiljøer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1751"/>
        <location filename="../src/mainwindow.cpp" line="5383"/>
        <source>All installed</source>
        <translation>Alle installerte</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1531"/>
        <location filename="../src/mainwindow.ui" line="1941"/>
        <source>Total items </source>
        <translation>Totalt antall</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1545"/>
        <source>Installed apps:</source>
        <translation>Installerte programmer:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1597"/>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1626"/>
        <source>Total installed size:</source>
        <translation>Totalt installert str:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1640"/>
        <source>Remove unused runtimes</source>
        <translation>Fjern ubrukte kjøreomgivelser</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="613"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <source>Select all</source>
        <translation>Velg alle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>AUR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="656"/>
        <source>search AUR (type to find more)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="763"/>
        <source>Tip: search to find other AUR packages. Installed AUR packages are shown when the search box is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <location filename="../src/mainwindow.ui" line="1230"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1798"/>
        <source>Snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1819"/>
        <location filename="../src/mainwindow.ui" line="1823"/>
        <location filename="../src/mainwindow_snap.cpp" line="234"/>
        <location filename="../src/mainwindow_snap.cpp" line="313"/>
        <source>Installed snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1828"/>
        <location filename="../src/mainwindow.cpp" line="5250"/>
        <location filename="../src/mainwindow_snap.cpp" line="149"/>
        <location filename="../src/mainwindow_snap.cpp" line="237"/>
        <location filename="../src/mainwindow_snap.cpp" line="239"/>
        <source>Search store</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1861"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1893"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1903"/>
        <source>Set up Snap support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1955"/>
        <source>Installed snaps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1982"/>
        <source>Update All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2005"/>
        <location filename="../src/mainwindow.cpp" line="4813"/>
        <location filename="../src/mainwindow.cpp" line="5206"/>
        <source>Console Output</source>
        <translation>Terminalutdata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2011"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2021"/>
        <source>Respond here, or just press Enter</source>
        <translation>Svar her eller trykk Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2080"/>
        <location filename="../src/mainwindow.cpp" line="2736"/>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <location filename="../src/mainwindow_snap.cpp" line="295"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2086"/>
        <source>Alt+I</source>
        <translation>Alt + I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2105"/>
        <source>Quit application</source>
        <translation>Avslutt programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2108"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2114"/>
        <source>Alt+C</source>
        <translation>Alt + C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2146"/>
        <source>About this application</source>
        <translation>Om programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2149"/>
        <source>About...</source>
        <translation>Om …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2155"/>
        <source>Alt+B</source>
        <translation>Alt + B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2193"/>
        <source>Display help </source>
        <translation>Vis hjelp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2196"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2202"/>
        <source>Alt+H</source>
        <translation>Alt + H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2218"/>
        <source>Uninstall</source>
        <translation>Avinstaller</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2224"/>
        <source>Alt+U</source>
        <translation>Alt + U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1040"/>
        <source>Uninstalling packages...</source>
        <translation>Avinstallerer pakker …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1045"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Utfører handlinger før avinstallering …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1063"/>
        <source>Running post-uninstall operations...</source>
        <translation>Utfører handlinger etter avinstallering …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1080"/>
        <source>Refreshing sources...</source>
        <translation>Oppdaterer kilder …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <location filename="../src/mainwindow.cpp" line="1093"/>
        <location filename="../src/mainwindow.cpp" line="2789"/>
        <location filename="../src/mainwindow.cpp" line="2821"/>
        <location filename="../src/mainwindow.cpp" line="2844"/>
        <location filename="../src/mainwindow.cpp" line="3013"/>
        <location filename="../src/mainwindow.cpp" line="3213"/>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <location filename="../src/mainwindow.cpp" line="3353"/>
        <location filename="../src/mainwindow.cpp" line="3729"/>
        <location filename="../src/mainwindow.cpp" line="3843"/>
        <location filename="../src/mainwindow.cpp" line="4496"/>
        <location filename="../src/mainwindow.cpp" line="4574"/>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="4991"/>
        <location filename="../src/mainwindow.cpp" line="5043"/>
        <location filename="../src/mainwindow.cpp" line="5653"/>
        <location filename="../src/mainwindow.cpp" line="5707"/>
        <location filename="../src/mainwindow.cpp" line="5839"/>
        <location filename="../src/mainwindow.cpp" line="5874"/>
        <location filename="../src/mainwindow.cpp" line="5981"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <location filename="../src/mainwindow_snap.cpp" line="33"/>
        <location filename="../src/mainwindow_aur.cpp" line="154"/>
        <location filename="../src/mainwindow_aur.cpp" line="186"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1094"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Det oppstod en feil under oppdatering av kilder. Noen kilder ble kanskje ikke oppdatert. Se følgende for mer informasjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1229"/>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Gjenkjente ikke Debian-versjon. Velg versjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1262"/>
        <source>Debian Version</source>
        <translation>Debian-versjon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1795"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1801"/>
        <source>Please wait...</source>
        <translation>Vennligst vent …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2525"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Du er i ferd med å ta i bruk pakkearkivet MX Test. Disse pakkene er ment for testing. De kan skade systemet ditt, så sørg for at du har en reservekopi, eller installer eller oppdater kun én pakke om gangen. Du kan gi tilbakemelding angående pakken i forumet slik at den kan evalueres før den flyttes til det vanlige pakkearkivet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2534"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Du er i ferd med å ta i bruk Debian Backports, som inneholder pakker fra neste Debian-utgivelse (&apos;testing&apos;) som er justert og omkompilert for bruk på stabil Debian-utgivelse. De er derfor ikke testet i like stor grad som pakkene i stabile utgivelser av Debian og MX Linux, og tilbys derfor som de er. De er ikke nødvendigvis kompatible med andre komponenter i stabil Debian-utgivelse. Tenk deg om.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2542"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux har med dette pakkearkivet med flatpaks til nytte for brukeren, men står ikke ansvarlig for funksjonaliteten til selve flatpaksene. Slå opp flatpaks i wikien for mer informasjon.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2558"/>
        <location filename="../src/mainwindow.cpp" line="6020"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2560"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldinga igjen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2733"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2624"/>
        <location filename="../src/mainwindow.cpp" line="2749"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Følgende pakker ble valgt. Velg «Vis detaljer» for liste over endringer.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="3014"/>
        <location filename="../src/mainwindow.cpp" line="3296"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internett er utilgjengelig, og listen med pakker kan derfor ikke lastes ned</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>Installing packages...</source>
        <translation>Installerer pakker …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2936"/>
        <source>Post-processing...</source>
        <translation>Etterbehandler …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2975"/>
        <source>Pre-processing for </source>
        <translation>Forbehandling av</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2985"/>
        <source>Installing </source>
        <translation>Installerer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2997"/>
        <source>Post-processing for </source>
        <translation>Etterbehandling av</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3210"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Feil ved nedlasting eller skriving til fil: %1. Undersøk internett-tilkoblingen og om det er nok ledig plass på disken.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3303"/>
        <source>Downloading package info...</source>
        <translation>Laster ned pakkeinformasjon …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <location filename="../src/mainwindow.cpp" line="4104"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4300"/>
        <source>Package info</source>
        <translation>Pakkeinformasjon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3993"/>
        <location filename="../src/mainwindow.cpp" line="5914"/>
        <source>More &amp;info...</source>
        <translation>Mer &amp;info …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4204"/>
        <source>Packages to be installed: </source>
        <translation>Pakker som skal installeres:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Done</source>
        <translation>Ferdig</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Processing finished successfully.</source>
        <translation>Prosessen er fullført.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4487"/>
        <location filename="../src/mainwindow.cpp" line="4547"/>
        <location filename="../src/mainwindow.cpp" line="5863"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <location filename="../src/mainwindow.cpp" line="3730"/>
        <location filename="../src/mainwindow.cpp" line="3844"/>
        <source>The installed-package query returned an error. Please check the log for details.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Show/hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>Clear input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2549"/>
        <source>You are about to use the AUR, which contains user-contributed packages. These packages are not vetted by the distribution, may be outdated, and could contain malicious or broken build scripts. Use with care.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2628"/>
        <source>Pacman will also perform a full system upgrade.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2822"/>
        <source>paru is not installed.

To install AUR packages, please install paru first:
pacman -S paru

Then try installing the AUR package again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2845"/>
        <source>AUR packages cannot be built as root, and no regular user could be found to build as.

Install the package as your normal user instead.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3209"/>
        <source>The download timed out. Please check your internet connection and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4087"/>
        <source>Developer: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4090"/>
        <source>License: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4094"/>
        <source>Homepage: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4188"/>
        <location filename="../src/mainwindow.cpp" line="4257"/>
        <location filename="../src/mainwindow_snap.cpp" line="574"/>
        <location filename="../src/mainwindow_aur.cpp" line="164"/>
        <source>No information available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4497"/>
        <location filename="../src/mainwindow.cpp" line="4575"/>
        <location filename="../src/mainwindow.cpp" line="5708"/>
        <location filename="../src/mainwindow.cpp" line="5840"/>
        <location filename="../src/mainwindow.cpp" line="5875"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Det oppstod et problem under installering. Se terminalutdata for mer informasjon.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4516"/>
        <source>Install snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4517"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4528"/>
        <source>Installing packages: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4531"/>
        <source>Installing package: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4552"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4587"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4588"/>
        <source>Version: </source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4590"/>
        <source>Package Installer for MX Linux</source>
        <translation>Verktøy for pakkeinstallering for MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4592"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Opphavsrett (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4593"/>
        <source>%1 License</source>
        <translation>Lisens for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4601"/>
        <location filename="../src/mainwindow.cpp" line="4603"/>
        <source>%1 Help</source>
        <translation>Hjelpetekst for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <location filename="../src/mainwindow.cpp" line="5970"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4726"/>
        <location filename="../src/mainwindow.cpp" line="4780"/>
        <location filename="../src/mainwindow.cpp" line="5972"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4727"/>
        <location filename="../src/mainwindow.cpp" line="5973"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Det oppstod et problem under avinstallering. Se utdata for mer informasjon.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4760"/>
        <source>Remove snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4761"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4785"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <source>Success</source>
        <translation>Vellykket</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Det oppstod et problem under avinstallering av programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3354"/>
        <location filename="../src/mainwindow.cpp" line="4992"/>
        <location filename="../src/mainwindow.cpp" line="5044"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Klarte ikke laste ned pakkeliste. Sjekk APT-kildene.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="155"/>
        <source>paru is not installed.

Install it with: pacman -S paru</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="187"/>
        <source>Could not query AUR packages. Please check that paru is installed and you are online.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5126"/>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak ikke installert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5127"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak er ikke installert.
Vil du installere nå?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak ble ikke installert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <location filename="../src/mainwindow_snap.cpp" line="478"/>
        <source>Needs re-login</source>
        <translation>Logg inn på nytt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5211"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Du må logge ut og inn igjen for å oppdatere menyen med de installerte programmene</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No results</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="367"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="399"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="465"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="470"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="474"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="504"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5494"/>
        <location filename="../src/mainwindow.cpp" line="5557"/>
        <source>Mark keep</source>
        <translation>Skal beholdes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5438"/>
        <source>Select/deselect all upgradable</source>
        <translation>Velg/fravelg alle som kan oppgraderes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5439"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Velg/fravelg alle som kan fjernes automatisk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <source>Upgrade</source>
        <translation>Oppgrader</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Show input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5769"/>
        <location filename="../src/mainwindow.cpp" line="5925"/>
        <source>Quit?</source>
        <translation>Avslutt?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5770"/>
        <location filename="../src/mainwindow.cpp" line="5926"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Prosessen kjører fortsatt. Hvis du avslutter nå så kan systemet bli ustabilt.&lt;p&gt;&lt;b&gt;Vil du virkelig avslutte MX Verktøy for pakkeinstallering?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <source>Reinstall</source>
        <translation>Installer på nytt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="479"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5832"/>
        <location filename="../src/mainwindow_snap.cpp" line="496"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5654"/>
        <location filename="../src/mainwindow.cpp" line="5982"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Det oppstod et problem under forrige handling. Se terminalutdata for mer informasjon.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="6021"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Mulig farlig handling.
Undersøk nøye hvilke pakker som skal fjernes.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Behandle eksterne Flatpak-arkiv</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>For alle brukere</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>For gjeldende bruker</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>angi adressen til eksternt Flatpak-arkiv</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>angi Flatpakref-adressen for å installere programmet</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Legg til eller fjern eksterne Flatpak-arkiv, eller installer programmer med flatpakref-adresse eller sti</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Fjern eksternt arkiv</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Legg til eksternt arkiv</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Installer program</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="85"/>
        <source>Not removable</source>
        <translation>Kan ikke fjernes</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="86"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub er det eksterne hovedarkivet og kan ikke fjernes</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="104"/>
        <source>Error removing remote</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Could not remove remote - command returned an error. Please try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="122"/>
        <source>Error adding remote</source>
        <translation>Klarte ikke legge til eksternt arkiv</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="123"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Klarte ikke legge til eksternt arkiv – kommandoen returnerte en feil. Undersøk adressen og forsøk igjen.</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Success</source>
        <translation>Vellykket</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Remote added successfully</source>
        <translation>La til eksternt arkiv</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="148"/>
        <source>Repo Version</source>
        <translation>Versjon i pakkearkiv</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="150"/>
        <source>Installed</source>
        <translation>Installert</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="152"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>License</source>
        <translation>Lisens</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <location filename="../src/about.cpp" line="113"/>
        <source>Changelog</source>
        <translation>Endringslogg</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="123"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="126"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="69"/>
        <location filename="../src/lockfile_apt.cpp" line="52"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="89"/>
        <source>no running process (stale lock file %1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="53"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Dpkg/apt-databasen er låst av et annet program: %1
Lukk dette programmet, eller vent til det er ferdig, og forsøk igjen.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="87"/>
        <source>another package manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Verktøy for pakkeinstallering brukes til å behandle pakker på MX Linux
– kan installere populære programmer fra ulike kilder
– kan installere programmer fra pakkearkivet MX Test
– kan installere programmer fra pakkearkivet Debian Backports
– kan installere flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Hopp over nettsjekk hvis den feilaktig sier at internett-tilgang mangler.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <location filename="../src/main.cpp" line="130"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du er innlogget som root. Vennligst logg ut, og logg inn igjen som en vanlig bruker for å bruke dette programmet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>You must run this program with admin access.</source>
        <translation>Dette programmet må kjøres med administratorrettigheter.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="70"/>
        <source>Pacman database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="89"/>
        <source>More info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="157"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Versjon</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="161"/>
        <source>Publisher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="163"/>
        <source>Notes</source>
        <translation>Merknader</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="165"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
</context>
</TS>