<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="zh_TW">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="534"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="535"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="93"/>
        <source>More info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="167"/>
        <source>Package</source>
        <translation>套件</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="169"/>
        <source>Info</source>
        <translation>資料</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="171"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="173"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="175"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Size</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>MX Package Installer</source>
        <translation>MX 軟體安裝工具</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>熱門程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="964"/>
        <location filename="../src/mainwindow.ui" line="1355"/>
        <location filename="../src/mainwindow.ui" line="1476"/>
        <location filename="../src/mainwindow.ui" line="1864"/>
        <source>search</source>
        <translation>搜尋</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="669"/>
        <location filename="../src/mainwindow.ui" line="989"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>= Installed packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1552"/>
        <source>Upgrade All</source>
        <translation>全部升級</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="808"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>Installed:</source>
        <translation>已安裝：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="801"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Total packages:</source>
        <translation>軟體總數：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <location filename="../src/mainwindow.ui" line="1260"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="838"/>
        <location filename="../src/mainwindow.ui" line="1185"/>
        <source>Upgradable:</source>
        <translation>可升級：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1220"/>
        <source>Hide library and developer packages</source>
        <translation>隱藏函式庫和軟體研發程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="600"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <location filename="../src/mainwindow.ui" line="1279"/>
        <location filename="../src/mainwindow.ui" line="1764"/>
        <location filename="../src/mainwindow.ui" line="1874"/>
        <source>Refresh list</source>
        <translation>重新載入清單</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="728"/>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <location filename="../src/mainwindow.ui" line="1816"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;依軟體狀態篩選。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="735"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <location filename="../src/mainwindow.ui" line="1058"/>
        <location filename="../src/mainwindow.ui" line="1388"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.cpp" line="5392"/>
        <source>All packages</source>
        <translation>所有軟體</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="740"/>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.ui" line="1397"/>
        <location filename="../src/mainwindow.cpp" line="5418"/>
        <source>Installed</source>
        <translation>已安裝</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="5419"/>
        <source>Upgradable</source>
        <translation>可升級</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1073"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.ui" line="1756"/>
        <location filename="../src/mainwindow.cpp" line="5385"/>
        <location filename="../src/mainwindow.cpp" line="5420"/>
        <source>Not installed</source>
        <translation>未安裝</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.ui" line="1078"/>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <location filename="../src/mainwindow.cpp" line="2144"/>
        <location filename="../src/mainwindow.cpp" line="5356"/>
        <location filename="../src/mainwindow.cpp" line="5421"/>
        <location filename="../src/mainwindow.cpp" line="5481"/>
        <source>Autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <location filename="../src/mainwindow.ui" line="1020"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>MX Test Repo</source>
        <translation>MX 測試倉庫</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Debian Backports</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <source>Flatpaks</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1687"/>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>For all users</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1696"/>
        <source>For current user</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1781"/>
        <source>Remote (repo):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1722"/>
        <location filename="../src/mainwindow.ui" line="1726"/>
        <location filename="../src/mainwindow.cpp" line="5367"/>
        <source>All apps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1731"/>
        <location filename="../src/mainwindow.cpp" line="5373"/>
        <source>All runtimes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1736"/>
        <location filename="../src/mainwindow.cpp" line="5379"/>
        <source>All available</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1741"/>
        <location filename="../src/mainwindow.cpp" line="5364"/>
        <source>Installed apps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1746"/>
        <location filename="../src/mainwindow.cpp" line="5361"/>
        <source>Installed runtimes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1751"/>
        <location filename="../src/mainwindow.cpp" line="5383"/>
        <source>All installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1531"/>
        <location filename="../src/mainwindow.ui" line="1941"/>
        <source>Total items </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1545"/>
        <source>Installed apps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1597"/>
        <source>Advanced</source>
        <translation>進階選項</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1626"/>
        <source>Total installed size:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1640"/>
        <source>Remove unused runtimes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="613"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>AUR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="656"/>
        <source>search AUR (type to find more)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="763"/>
        <source>Tip: search to find other AUR packages. Installed AUR packages are shown when the search box is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <location filename="../src/mainwindow.ui" line="1230"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1798"/>
        <source>Snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1819"/>
        <location filename="../src/mainwindow.ui" line="1823"/>
        <location filename="../src/mainwindow_snap.cpp" line="234"/>
        <location filename="../src/mainwindow_snap.cpp" line="313"/>
        <source>Installed snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1828"/>
        <location filename="../src/mainwindow.cpp" line="5250"/>
        <location filename="../src/mainwindow_snap.cpp" line="149"/>
        <location filename="../src/mainwindow_snap.cpp" line="237"/>
        <location filename="../src/mainwindow_snap.cpp" line="239"/>
        <source>Search store</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1861"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1893"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1903"/>
        <source>Set up Snap support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1955"/>
        <source>Installed snaps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1982"/>
        <source>Update All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2005"/>
        <location filename="../src/mainwindow.cpp" line="4813"/>
        <location filename="../src/mainwindow.cpp" line="5206"/>
        <source>Console Output</source>
        <translation>終端機輸出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2011"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2021"/>
        <source>Respond here, or just press Enter</source>
        <translation>在此回覆，或只按 Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2080"/>
        <location filename="../src/mainwindow.cpp" line="2736"/>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <location filename="../src/mainwindow_snap.cpp" line="295"/>
        <source>Install</source>
        <translation>安裝</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2086"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2105"/>
        <source>Quit application</source>
        <translation>退出程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2108"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2114"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2146"/>
        <source>About this application</source>
        <translation>關於本程式</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2149"/>
        <source>About...</source>
        <translation>關於……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2155"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2193"/>
        <source>Display help </source>
        <translation>顯示說明</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2196"/>
        <source>Help</source>
        <translation>說明</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2202"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2218"/>
        <source>Uninstall</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2224"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1040"/>
        <source>Uninstalling packages...</source>
        <translation>正在移除軟體……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1045"/>
        <source>Running pre-uninstall operations...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1063"/>
        <source>Running post-uninstall operations...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1080"/>
        <source>Refreshing sources...</source>
        <translation>更新來源……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <location filename="../src/mainwindow.cpp" line="1093"/>
        <location filename="../src/mainwindow.cpp" line="2789"/>
        <location filename="../src/mainwindow.cpp" line="2821"/>
        <location filename="../src/mainwindow.cpp" line="2844"/>
        <location filename="../src/mainwindow.cpp" line="3013"/>
        <location filename="../src/mainwindow.cpp" line="3213"/>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <location filename="../src/mainwindow.cpp" line="3353"/>
        <location filename="../src/mainwindow.cpp" line="3729"/>
        <location filename="../src/mainwindow.cpp" line="3843"/>
        <location filename="../src/mainwindow.cpp" line="4496"/>
        <location filename="../src/mainwindow.cpp" line="4574"/>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="4991"/>
        <location filename="../src/mainwindow.cpp" line="5043"/>
        <location filename="../src/mainwindow.cpp" line="5653"/>
        <location filename="../src/mainwindow.cpp" line="5707"/>
        <location filename="../src/mainwindow.cpp" line="5839"/>
        <location filename="../src/mainwindow.cpp" line="5874"/>
        <location filename="../src/mainwindow.cpp" line="5981"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <location filename="../src/mainwindow_snap.cpp" line="33"/>
        <location filename="../src/mainwindow_aur.cpp" line="154"/>
        <location filename="../src/mainwindow_aur.cpp" line="186"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1094"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>更新來源時發生問題。可能有一些軟體來源並未提供更新檔。詳細訊息請見：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1229"/>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1262"/>
        <source>Debian Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1795"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1801"/>
        <source>Please wait...</source>
        <translation>請稍待……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2525"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2534"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>即將利用 Debian 回溯移植倉庫，裡面的軟體來自 Debian 下一個正式發行版（稱為 &apos;testing&apos; ），經過調校、編譯，以供 Debian 安定版使用。這些軟體的測試過程沒辦法像 Debian 和 MX Linux 的安定版那麼精細，基本上它們以依其所是的狀態提供出來，有可能與 Debian 安定版當中的其他元件並不相容。小心使用！</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2542"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2558"/>
        <location filename="../src/mainwindow.cpp" line="6020"/>
        <source>Warning</source>
        <translation>注意</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2560"/>
        <source>Do not show this message again</source>
        <translation>不再顯示此一訊息</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2733"/>
        <source>Remove</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2624"/>
        <location filename="../src/mainwindow.cpp" line="2749"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="3014"/>
        <location filename="../src/mainwindow.cpp" line="3296"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>無法連上網際網路，因此不能下載軟體列表。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>Installing packages...</source>
        <translation>正在安裝軟體……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2936"/>
        <source>Post-processing...</source>
        <translation>後續處理當中……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2975"/>
        <source>Pre-processing for </source>
        <translation>前置處理</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2985"/>
        <source>Installing </source>
        <translation>正在安裝……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2997"/>
        <source>Post-processing for </source>
        <translation>後續處理</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3210"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3303"/>
        <source>Downloading package info...</source>
        <translation>正在下載軟體資料……</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <location filename="../src/mainwindow.cpp" line="4104"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4300"/>
        <source>Package info</source>
        <translation>軟體資料</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3993"/>
        <location filename="../src/mainwindow.cpp" line="5914"/>
        <source>More &amp;info...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4204"/>
        <source>Packages to be installed: </source>
        <translation>即將安裝的軟體：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Done</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Processing finished successfully.</source>
        <translation>程序順利進行完畢。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4487"/>
        <location filename="../src/mainwindow.cpp" line="4547"/>
        <location filename="../src/mainwindow.cpp" line="5863"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <location filename="../src/mainwindow.cpp" line="3730"/>
        <location filename="../src/mainwindow.cpp" line="3844"/>
        <source>The installed-package query returned an error. Please check the log for details.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Show/hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>Clear input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2549"/>
        <source>You are about to use the AUR, which contains user-contributed packages. These packages are not vetted by the distribution, may be outdated, and could contain malicious or broken build scripts. Use with care.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2628"/>
        <source>Pacman will also perform a full system upgrade.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2822"/>
        <source>paru is not installed.

To install AUR packages, please install paru first:
pacman -S paru

Then try installing the AUR package again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2845"/>
        <source>AUR packages cannot be built as root, and no regular user could be found to build as.

Install the package as your normal user instead.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3209"/>
        <source>The download timed out. Please check your internet connection and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4087"/>
        <source>Developer: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4090"/>
        <source>License: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4094"/>
        <source>Homepage: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4188"/>
        <location filename="../src/mainwindow.cpp" line="4257"/>
        <location filename="../src/mainwindow_snap.cpp" line="574"/>
        <location filename="../src/mainwindow_aur.cpp" line="164"/>
        <source>No information available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4497"/>
        <location filename="../src/mainwindow.cpp" line="4575"/>
        <location filename="../src/mainwindow.cpp" line="5708"/>
        <location filename="../src/mainwindow.cpp" line="5840"/>
        <location filename="../src/mainwindow.cpp" line="5875"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>安裝軟體時發現問題，請參考終端機輸出的訊息。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4516"/>
        <source>Install snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4517"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4528"/>
        <source>Installing packages: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4531"/>
        <source>Installing package: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4552"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4587"/>
        <source>About %1</source>
        <translation>大約 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4588"/>
        <source>Version: </source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4590"/>
        <source>Package Installer for MX Linux</source>
        <translation>MX Linux 軟體安裝工具</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4592"/>
        <source>Copyright (c) MX Linux</source>
        <translation>版權所有 (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4593"/>
        <source>%1 License</source>
        <translation>%1 許可</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4601"/>
        <location filename="../src/mainwindow.cpp" line="4603"/>
        <source>%1 Help</source>
        <translation>%1 幫助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <location filename="../src/mainwindow.cpp" line="5970"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4726"/>
        <location filename="../src/mainwindow.cpp" line="4780"/>
        <location filename="../src/mainwindow.cpp" line="5972"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4727"/>
        <location filename="../src/mainwindow.cpp" line="5973"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4760"/>
        <source>Remove snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4761"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4785"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>移除該程式時發生問題</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3354"/>
        <location filename="../src/mainwindow.cpp" line="4992"/>
        <location filename="../src/mainwindow.cpp" line="5044"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="155"/>
        <source>paru is not installed.

Install it with: pacman -S paru</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="187"/>
        <source>Could not query AUR packages. Please check that paru is installed and you are online.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5126"/>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak not installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5127"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak was not installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <location filename="../src/mainwindow_snap.cpp" line="478"/>
        <source>Needs re-login</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5211"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No results</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="367"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="399"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="465"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="470"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="474"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="504"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5494"/>
        <location filename="../src/mainwindow.cpp" line="5557"/>
        <source>Mark keep</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5438"/>
        <source>Select/deselect all upgradable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5439"/>
        <source>Select/deselect all autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <source>Upgrade</source>
        <translation>升級</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Show input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5769"/>
        <location filename="../src/mainwindow.cpp" line="5925"/>
        <source>Quit?</source>
        <translation>退出？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5770"/>
        <location filename="../src/mainwindow.cpp" line="5926"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <source>Reinstall</source>
        <translation>重新安裝</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="479"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5832"/>
        <location filename="../src/mainwindow_snap.cpp" line="496"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5654"/>
        <location filename="../src/mainwindow.cpp" line="5982"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="6021"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="85"/>
        <source>Not removable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="86"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="104"/>
        <source>Error removing remote</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Could not remove remote - command returned an error. Please try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="122"/>
        <source>Error adding remote</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="123"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Remote added successfully</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="146"/>
        <source>Package</source>
        <translation>套件</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="148"/>
        <source>Repo Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="150"/>
        <source>Installed</source>
        <translation>已安裝</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="152"/>
        <source>Description</source>
        <translation>簡介</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>套件</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>資料</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>簡介</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>License</source>
        <translation>授權條款</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <location filename="../src/about.cpp" line="113"/>
        <source>Changelog</source>
        <translation>變更紀錄</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="123"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="126"/>
        <source>&amp;Close</source>
        <translation>關閉（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="69"/>
        <location filename="../src/lockfile_apt.cpp" line="52"/>
        <source>Warning</source>
        <translation>注意</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="89"/>
        <source>no running process (stale lock file %1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="53"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="87"/>
        <source>another package manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <location filename="../src/main.cpp" line="130"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>您似乎是以 root 身份登錄，請登出並以一般使用者身份登錄以使用此程式。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>You must run this program with admin access.</source>
        <translation>您必須以系統管理員權限執行此程式。</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="70"/>
        <source>Pacman database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="89"/>
        <source>More info</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>套件</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="157"/>
        <source>Info</source>
        <translation>資料</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="161"/>
        <source>Publisher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="163"/>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="165"/>
        <source>Description</source>
        <translation>簡介</translation>
    </message>
</context>
</TS>