<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fi">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="534"/>
        <source>Administrator Access Required</source>
        <translation>Pääkäyttäjän oikeudet vaaditaan</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="535"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation>Tämä toiminto vaatii pääkäyttäjäoikeudet. Yritä toimintoa uudelleen ja syötä salasanasi kysyttäessä.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="93"/>
        <source>More info</source>
        <translation>Lisätietoa</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="167"/>
        <source>Package</source>
        <translation>Paketti</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="169"/>
        <source>Info</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="171"/>
        <source>Full Name</source>
        <translation>Koko nimi</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="173"/>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="175"/>
        <source>Branch</source>
        <translation>Haara</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>MX Package Installer</source>
        <translation>MX Sovellukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Suositut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Suosittuja paketteja&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="964"/>
        <location filename="../src/mainwindow.ui" line="1355"/>
        <location filename="../src/mainwindow.ui" line="1476"/>
        <location filename="../src/mainwindow.ui" line="1864"/>
        <source>search</source>
        <translation>hae</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="669"/>
        <location filename="../src/mainwindow.ui" line="989"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>= Installed packages</source>
        <translation>= tietokoneeseen asennetut paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Arkistot käytössä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Poistaa kaikki paketit, jotka on merkitty &quot;automaattisesti poistettaviksi&quot;. Jos haluat tehdä muutoksia, valitse Autom. poistettavat pudotusvalikosta.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Autom. poistettavat paketit </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1552"/>
        <source>Upgrade All</source>
        <translation>Päivitä kaikki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="808"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>Installed:</source>
        <translation>Asennettu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="801"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>Total packages:</source>
        <translation>Paketteja:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <location filename="../src/mainwindow.ui" line="1260"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Asenna myös &quot;suositellut&quot; paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="838"/>
        <location filename="../src/mainwindow.ui" line="1185"/>
        <source>Upgradable:</source>
        <translation>Päivitettävissä:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1220"/>
        <source>Hide library and developer packages</source>
        <translation>Piilota kirjasto ja kehittäjäpaketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="600"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <location filename="../src/mainwindow.ui" line="1279"/>
        <location filename="../src/mainwindow.ui" line="1764"/>
        <location filename="../src/mainwindow.ui" line="1874"/>
        <source>Refresh list</source>
        <translation>Päivitä luettelo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="728"/>
        <location filename="../src/mainwindow.ui" line="1051"/>
        <location filename="../src/mainwindow.ui" line="1385"/>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <location filename="../src/mainwindow.ui" line="1816"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suodata paketit niiden tilan suhteen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="735"/>
        <location filename="../src/mainwindow.ui" line="1054"/>
        <location filename="../src/mainwindow.ui" line="1058"/>
        <location filename="../src/mainwindow.ui" line="1388"/>
        <location filename="../src/mainwindow.ui" line="1392"/>
        <location filename="../src/mainwindow.cpp" line="5392"/>
        <source>All packages</source>
        <translation>Kaikki paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="740"/>
        <location filename="../src/mainwindow.ui" line="1063"/>
        <location filename="../src/mainwindow.ui" line="1397"/>
        <location filename="../src/mainwindow.cpp" line="5418"/>
        <source>Installed</source>
        <translation>Asennettu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="5419"/>
        <source>Upgradable</source>
        <translation>Päivitettävissä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="750"/>
        <location filename="../src/mainwindow.ui" line="1073"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.ui" line="1756"/>
        <location filename="../src/mainwindow.cpp" line="5385"/>
        <location filename="../src/mainwindow.cpp" line="5420"/>
        <source>Not installed</source>
        <translation>Ei asennettu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.ui" line="1078"/>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <location filename="../src/mainwindow.cpp" line="2144"/>
        <location filename="../src/mainwindow.cpp" line="5356"/>
        <location filename="../src/mainwindow.cpp" line="5421"/>
        <location filename="../src/mainwindow.cpp" line="5481"/>
        <source>Autoremovable</source>
        <translation>Autom. poistettavat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <location filename="../src/mainwindow.ui" line="1020"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= päivitettävissä oleva paketti. Uudempi versio on saatavilla valitusta lähteestä.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>MX Test Repo</source>
        <translation>MX Test Repo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <source>Flatpaks</source>
        <translation>Flatpakit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1687"/>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>For all users</source>
        <translation>Kaikille käyttäjille</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1696"/>
        <source>For current user</source>
        <translation>Vain minulle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1781"/>
        <source>Remote (repo):</source>
        <translation>Ulkopuolinen (arkisto):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1722"/>
        <location filename="../src/mainwindow.ui" line="1726"/>
        <location filename="../src/mainwindow.cpp" line="5367"/>
        <source>All apps</source>
        <translation>Kaikki sovellukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1731"/>
        <location filename="../src/mainwindow.cpp" line="5373"/>
        <source>All runtimes</source>
        <translation>Kaikki suoritusympäristöt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1736"/>
        <location filename="../src/mainwindow.cpp" line="5379"/>
        <source>All available</source>
        <translation>Kaikki saatavilla olevat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1741"/>
        <location filename="../src/mainwindow.cpp" line="5364"/>
        <source>Installed apps</source>
        <translation>Asennetut sovellukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1746"/>
        <location filename="../src/mainwindow.cpp" line="5361"/>
        <source>Installed runtimes</source>
        <translation>Asennetut suoritusympäristöt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1751"/>
        <location filename="../src/mainwindow.cpp" line="5383"/>
        <source>All installed</source>
        <translation>Kaikki asennetut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1531"/>
        <location filename="../src/mainwindow.ui" line="1941"/>
        <source>Total items </source>
        <translation>Kohteita:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1545"/>
        <source>Installed apps:</source>
        <translation>Asennetut sovellukset:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1597"/>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1626"/>
        <source>Total installed size:</source>
        <translation>Koko asennettuna:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1640"/>
        <source>Remove unused runtimes</source>
        <translation>Poista käyttämättömät suoritusajat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="613"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <source>Select all</source>
        <translation>Valitse kaikki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>AUR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="656"/>
        <source>search AUR (type to find more)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="763"/>
        <source>Tip: search to find other AUR packages. Installed AUR packages are shown when the search box is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <location filename="../src/mainwindow.ui" line="1230"/>
        <source>Only repo packages</source>
        <translation>Vain arkiston paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1798"/>
        <source>Snaps</source>
        <translation>Snap-paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1819"/>
        <location filename="../src/mainwindow.ui" line="1823"/>
        <location filename="../src/mainwindow_snap.cpp" line="234"/>
        <location filename="../src/mainwindow_snap.cpp" line="313"/>
        <source>Installed snaps</source>
        <translation>Asennetut paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1828"/>
        <location filename="../src/mainwindow.cpp" line="5250"/>
        <location filename="../src/mainwindow_snap.cpp" line="149"/>
        <location filename="../src/mainwindow_snap.cpp" line="237"/>
        <location filename="../src/mainwindow_snap.cpp" line="239"/>
        <source>Search store</source>
        <translation>Etsi snap-varastosta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1861"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Kirjoita hakusana ja paina Enter-nappia etsiäksesi snap-varastosta.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1893"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation>Snap-tuki ei ole vielä käytössä. Paina nappia asentaaksesi snapd:n ja ottaaksesi Snap-palvelun käyttöön.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1903"/>
        <source>Set up Snap support</source>
        <translation>Ota Snap-tuki käyttöön</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1955"/>
        <source>Installed snaps:</source>
        <translation>Asennetut snap-paketit.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1982"/>
        <source>Update All</source>
        <translation>Päivitä kaikki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2005"/>
        <location filename="../src/mainwindow.cpp" line="4813"/>
        <location filename="../src/mainwindow.cpp" line="5206"/>
        <source>Console Output</source>
        <translation>Konsoli</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2011"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2021"/>
        <source>Respond here, or just press Enter</source>
        <translation>Vastaa tähän, tai paina vain Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2080"/>
        <location filename="../src/mainwindow.cpp" line="2736"/>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <location filename="../src/mainwindow.cpp" line="5596"/>
        <location filename="../src/mainwindow_snap.cpp" line="295"/>
        <source>Install</source>
        <translation>Asenna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2086"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2105"/>
        <source>Quit application</source>
        <translation>Sulje sovellus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2108"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2114"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2146"/>
        <source>About this application</source>
        <translation>Tietoja sovelluksesta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2149"/>
        <source>About...</source>
        <translation>Tietoja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2155"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2193"/>
        <source>Display help </source>
        <translation>Näytä ohje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2196"/>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2202"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2218"/>
        <source>Uninstall</source>
        <translation>Poista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="2224"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1040"/>
        <source>Uninstalling packages...</source>
        <translation>Poistetaan paketteja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1045"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Suoritetaan asennusta edeltäviä poistoja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1063"/>
        <source>Running post-uninstall operations...</source>
        <translation>Ajetaan jälkiasennuksen toimia...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1080"/>
        <source>Refreshing sources...</source>
        <translation>Päivitetään lähdeluetteloita...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <location filename="../src/mainwindow.cpp" line="1093"/>
        <location filename="../src/mainwindow.cpp" line="2789"/>
        <location filename="../src/mainwindow.cpp" line="2821"/>
        <location filename="../src/mainwindow.cpp" line="2844"/>
        <location filename="../src/mainwindow.cpp" line="3013"/>
        <location filename="../src/mainwindow.cpp" line="3213"/>
        <location filename="../src/mainwindow.cpp" line="3295"/>
        <location filename="../src/mainwindow.cpp" line="3353"/>
        <location filename="../src/mainwindow.cpp" line="3729"/>
        <location filename="../src/mainwindow.cpp" line="3843"/>
        <location filename="../src/mainwindow.cpp" line="4496"/>
        <location filename="../src/mainwindow.cpp" line="4574"/>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="4991"/>
        <location filename="../src/mainwindow.cpp" line="5043"/>
        <location filename="../src/mainwindow.cpp" line="5653"/>
        <location filename="../src/mainwindow.cpp" line="5707"/>
        <location filename="../src/mainwindow.cpp" line="5839"/>
        <location filename="../src/mainwindow.cpp" line="5874"/>
        <location filename="../src/mainwindow.cpp" line="5981"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <location filename="../src/mainwindow_snap.cpp" line="33"/>
        <location filename="../src/mainwindow_aur.cpp" line="154"/>
        <location filename="../src/mainwindow_aur.cpp" line="186"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1094"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Lähteitä päivitettäessä kohdattiin ongelma. Jotkut lähteet eivät ehkä tuottaneet näytille päivityksiä. Lisätietoja varten:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1229"/>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Ei voitu määrittää Debian-versiota. Valitse versio:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1262"/>
        <source>Debian Version</source>
        <translation>Debian-versio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1795"/>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1801"/>
        <source>Please wait...</source>
        <translation>Odota, ole hyvä...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2525"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Olet aikeissa käyttää MX Testiarkistoa, jonka paketit on tarkoitettu vain testikäyttöön. Ne saattavat rikkoa järjestelmäsi, joten on suositeltavaa että varmuuskopioit järjestelmäsi sekä asennat tai päivität vain yhden paketin kerrallaan. Anna palautetta paketista ja sen toimivuudesta foorumilla, jotta paketti voidaan arvioida ennen sen siirtämistä varsinaiseen jakeluun.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2534"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Olet aikomuksessa käyttää Debian:in Takaporttiohjelmistolähdettä, joka sisältää paketteja, jotka ovat otetut tulevasta Debian:in julkaisusta (nimeltään &apos;testing&apos;), säädettynä ja uudelleenkoottuna käytettäväksi sitten Debian:in vakaassa julkaisussa myöhemmin. Niitä ei ole voitu testata yhtä läpikotaisesti kuten Debian:in ja antiX:in vakaiden julkaisujen suhteen ja ne on annettu tarjolle sellaisena kuin ne sillä hetkellä ovat, sisältäen yhteensopivuusriskejä Debian:in vakaaseenjulkaisuun verrattuna. Käytä siis varauksella! </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2542"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux sisällyttää flatpak ohjelmat vain käyttäjän mukavuutta tavoitellen, eikä ole itse vastuussa flatpakien toimivuudesta. Lisätietoja, lue Wiki-sivujen osiosta flatpak.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2558"/>
        <location filename="../src/mainwindow.cpp" line="6020"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2560"/>
        <source>Do not show this message again</source>
        <translation>Älä näytä tätä viestiä uudelleen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2733"/>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2624"/>
        <location filename="../src/mainwindow.cpp" line="2749"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Seuraavat paketit valittiin. Painike &quot;Näytä tiedot&quot; näyttää luettelon muutoksista.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="3014"/>
        <location filename="../src/mainwindow.cpp" line="3296"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet ei ole käytettävissä, pakettilistauksen lataaminen ei onnistu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>Installing packages...</source>
        <translation>Asennetaan paketteja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2936"/>
        <source>Post-processing...</source>
        <translation>Esikäsittely käynnissä...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2975"/>
        <source>Pre-processing for </source>
        <translation>Esikäsittely kohteelle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2985"/>
        <source>Installing </source>
        <translation>Asennetaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2997"/>
        <source>Post-processing for </source>
        <translation>Jälkikäsittely kohteelle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3210"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Virhe ladattaessa tai kirjoitettaessa: %1. Tarkista Internet-yhteys ja aseman vapaa tila</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3303"/>
        <source>Downloading package info...</source>
        <translation>Paketin tietoja ladataan...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3957"/>
        <location filename="../src/mainwindow.cpp" line="4104"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4300"/>
        <source>Package info</source>
        <translation>Paketin tiedot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3993"/>
        <location filename="../src/mainwindow.cpp" line="5914"/>
        <source>More &amp;info...</source>
        <translation>&amp;Lisätietoja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4204"/>
        <source>Packages to be installed: </source>
        <translation>Paketit, jotka tullaan asentamaan:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Done</source>
        <translation>Valmis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4492"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <location filename="../src/mainwindow.cpp" line="4736"/>
        <location filename="../src/mainwindow.cpp" line="4782"/>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="5704"/>
        <location filename="../src/mainwindow.cpp" line="5835"/>
        <location filename="../src/mainwindow.cpp" line="5868"/>
        <location filename="../src/mainwindow.cpp" line="5977"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <location filename="../src/mainwindow_snap.cpp" line="499"/>
        <source>Processing finished successfully.</source>
        <translation>Käsittely päättyi onnistuneesti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4487"/>
        <location filename="../src/mainwindow.cpp" line="4547"/>
        <location filename="../src/mainwindow.cpp" line="5863"/>
        <source>Install complete.</source>
        <translation>Asennus valmis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <location filename="../src/mainwindow.cpp" line="3730"/>
        <location filename="../src/mainwindow.cpp" line="3844"/>
        <source>The installed-package query returned an error. Please check the log for details.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Show/hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>Clear input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2549"/>
        <source>You are about to use the AUR, which contains user-contributed packages. These packages are not vetted by the distribution, may be outdated, and could contain malicious or broken build scripts. Use with care.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2628"/>
        <source>Pacman will also perform a full system upgrade.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2822"/>
        <source>paru is not installed.

To install AUR packages, please install paru first:
pacman -S paru

Then try installing the AUR package again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2845"/>
        <source>AUR packages cannot be built as root, and no regular user could be found to build as.

Install the package as your normal user instead.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3209"/>
        <source>The download timed out. Please check your internet connection and try again.</source>
        <translation>Lataus ei onnistunut. Tarkista internetyhteys ja yritä uudelleen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4087"/>
        <source>Developer: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4090"/>
        <source>License: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4094"/>
        <source>Homepage: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4188"/>
        <location filename="../src/mainwindow.cpp" line="4257"/>
        <location filename="../src/mainwindow_snap.cpp" line="574"/>
        <location filename="../src/mainwindow_aur.cpp" line="164"/>
        <source>No information available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4497"/>
        <location filename="../src/mainwindow.cpp" line="4575"/>
        <location filename="../src/mainwindow.cpp" line="5708"/>
        <location filename="../src/mainwindow.cpp" line="5840"/>
        <location filename="../src/mainwindow.cpp" line="5875"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Asennuksen aikana havaittiin ongelma, tutki konsolitulostetta.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4516"/>
        <source>Install snaps</source>
        <translation>Asenna snap-paketteja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4517"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation>Asennetaanko seuraavat snap-paketit?

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4528"/>
        <source>Installing packages: %1...</source>
        <translation>Asennetaan paketteja: %1...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4531"/>
        <source>Installing package: %1...</source>
        <translation>Asennetaan pakettia: %1...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4552"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation>Ongelma snap-pakettia asennettaessa. Klikkaa &quot;näytä yksityiskohdat&quot;-nappia saadaksesi lisätietoja.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4587"/>
        <source>About %1</source>
        <translation>%1 lisätietoja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4588"/>
        <source>Version: </source>
        <translation>Versio: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4590"/>
        <source>Package Installer for MX Linux</source>
        <translation>Pakettien asennus MX Linux:lle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4592"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4593"/>
        <source>%1 License</source>
        <translation>%1 lisenssi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4601"/>
        <location filename="../src/mainwindow.cpp" line="4603"/>
        <source>%1 Help</source>
        <translation>%1 ohje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <location filename="../src/mainwindow.cpp" line="5970"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Poistetaan flatpak asennuksia...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4726"/>
        <location filename="../src/mainwindow.cpp" line="4780"/>
        <location filename="../src/mainwindow.cpp" line="5972"/>
        <source>Uninstall complete.</source>
        <translation>Poisto valmis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4727"/>
        <location filename="../src/mainwindow.cpp" line="5973"/>
        <source>Refreshing flatpaks...</source>
        <translation>Virkistetään flatpak...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4740"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Poistamisen aikana kohdattiin ongelma, tarkista tuloste.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4760"/>
        <source>Remove snaps</source>
        <translation>Poista snap-paketteja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4761"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation>Poistetaanko seuraavat snap-paketit?

%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4785"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation>Ongelma poistettaessa snap-pakettia. Klikkaa &quot;näytä yksityiskohdat&quot;-nappia saadaksesi lisätietoja.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4800"/>
        <location filename="../src/mainwindow.cpp" line="6027"/>
        <source>Success</source>
        <translation>Onnistui</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <location filename="../src/mainwindow.cpp" line="6030"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Ohjelman poistamisen aikana kohdattiin ongelma</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3354"/>
        <location filename="../src/mainwindow.cpp" line="4992"/>
        <location filename="../src/mainwindow.cpp" line="5044"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Ei voitu ladata pakettiluetteloa. Tarkista APT-lähteet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="155"/>
        <source>paru is not installed.

Install it with: pacman -S paru</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow_aur.cpp" line="187"/>
        <source>Could not query AUR packages. Please check that paru is installed and you are online.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5126"/>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak ei ole asennettuna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5127"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak ei ole tällä hetkellä asennettuna.
Voinko asentaa sen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak ei ole asennettuna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5210"/>
        <location filename="../src/mainwindow_snap.cpp" line="478"/>
        <source>Needs re-login</source>
        <translation>Kirjautuminen uudelleen tarvitaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5211"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Sinun tulee kirjautua ulos ja takaisin sisään, jotta asennetut kohteet ilmestyvät valikkoon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No results</source>
        <translation>Ei tuloksia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="261"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation>Ehtoon &quot;%1&quot; täsmääviä snap-paketteja ei löytynyt.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="367"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation>Snapd-paketti ei ole asennettu. Klikkaa &quot;näytä yksityiskohdat&quot;-nappia saadaksesi lisätietoja.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="399"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation>Asennetaan Snapin &quot;core&quot;-pakettia...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="465"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation>Tulostetta ei voida näyttää. Aja päätteessä komento &quot;sudo snap install core&quot;, jos haluat nähdä virhetulosteen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="470"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation>Snapd-asennettiin, mutta Snap-palvelun käynnistäminen ei onnistunut. Tietokone on ehkä käynnistettävä uudelleen tai sitten joudut kirjautumaan ulos ja takaisin sisään, ja sitten avaamaan uudestaan Snap-välilehden. Klikkaa &quot;näytä yksityiskohdat&quot;-nappia saadaksesi lisätietoja.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="474"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation>Snap-tuki saatiin asennettua, mutta &quot;core&quot;-snap-paketin asennus ei onnistunut, joten suurin osa snap-paketeista ei vielä toimi. Klikkaa &quot;näytä yksityiskohdat&quot;-nappia nähdäksesi tarkemman virheilmoituksen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="504"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation>Ongelma päivitettäessä snap-paketteja. Klikkaa &quot;näytä yksityiskohdat&quot;-nappia saadaksesi lisätietoja.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5405"/>
        <location filename="../src/mainwindow.cpp" line="5416"/>
        <location filename="../src/mainwindow.cpp" line="5494"/>
        <location filename="../src/mainwindow.cpp" line="5557"/>
        <source>Mark keep</source>
        <translation>Merkitse pidä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5438"/>
        <source>Select/deselect all upgradable</source>
        <translation>Valitse kaikki päivitettävät/poista valinnat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5439"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Valitse kaikki autom. poistettavat/poista valinnat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5496"/>
        <location filename="../src/mainwindow.cpp" line="5555"/>
        <source>Upgrade</source>
        <translation>Päivitä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Show input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5760"/>
        <source>Hide input</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5769"/>
        <location filename="../src/mainwindow.cpp" line="5925"/>
        <source>Quit?</source>
        <translation>Lopeta?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5770"/>
        <location filename="../src/mainwindow.cpp" line="5926"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Prosessi on edelleen käynnissä, lopettaminen saattaa jättää järjestelmän epävakaaseen tilaan. &lt;p&gt;&lt;b&gt; Haluatko poistua MX Sovellukset ohjelmasta?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5535"/>
        <source>Reinstall</source>
        <translation>Asenna uudelleen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_snap.cpp" line="479"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5832"/>
        <location filename="../src/mainwindow_snap.cpp" line="496"/>
        <source>Update complete.</source>
        <translation>Päivitys valmis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5654"/>
        <location filename="../src/mainwindow.cpp" line="5982"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Ongelma havaittiin viimeisen toiminnon aikana, tarkista mitä konsolissa sanotaan.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="6021"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Mahdollisesti vaarallista.
Varmista, että tarkistat huolellisesti poistettavien pakettien luettelo.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Hallinnoi flatpak-ohjelmalähteitä</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Kaikille käyttäjille</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Vain minulle</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>kirjoita flatpak-ohjelmalähteen URL-osoite</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>kirjoita flatpakref-sijainti asentaaksesi sovelluksen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Lisää tai poista flatpak arkistot (ohjelmavarastot), tai asenna sovelluksia käyttäen flatpakref URL-osoitetta tai polkua</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Poista ohjelmalähde</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Lisää ohjelmalähde</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Asenna sovellus</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="85"/>
        <source>Not removable</source>
        <translation>Ei poistettavissa</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="86"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub on ensisijainen flatpak-ohjelmalähde ja sitä ei voi poistaa</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="104"/>
        <source>Error removing remote</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Could not remove remote - command returned an error. Please try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="122"/>
        <source>Error adding remote</source>
        <translation>Virhe lisättäessä ohjelmalähdettä</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="123"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Ohjelmalähdettä ei voitu lisätä - käsky palautti virheen. Tarkista ohjelmalähteen osoite ja yritä uudelleen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Success</source>
        <translation>Onnistui</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="128"/>
        <source>Remote added successfully</source>
        <translation>Ohjelmalähde lisätty onnistuneesti</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Paketti</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="148"/>
        <source>Repo Version</source>
        <translation>Arkiston versio</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="150"/>
        <source>Installed</source>
        <translation>Asennettu</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="152"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategoria</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paketti</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Ei voi ladata %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>License</source>
        <translation>Lisenssi</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <location filename="../src/about.cpp" line="113"/>
        <source>Changelog</source>
        <translation>Muutosloki</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="123"/>
        <source>Could not load changelog.</source>
        <translation>Muutoslokin lataaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="126"/>
        <source>&amp;Close</source>
        <translation>&amp;Sulje</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="69"/>
        <location filename="../src/lockfile_apt.cpp" line="52"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="89"/>
        <source>no running process (stale lock file %1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="53"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Toinen ohjelma on lukinnut Dpkg/apt-tietokannan: %1
Sulje ohjelma tai odota, kunnes se on valmiina  ja yritä uudelleen.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_apt.cpp" line="87"/>
        <source>another package manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Sovellukset on työkalu pakettien hallintaan MX Linux:ssa
    - asentaa suosittuja ohjelmia eri lähteistä
    - asentaa ohjelmia MX testilähteestä
    - asentaa ohjelmia Debian Backports lähteestä
    - asentaa flatpak-ohjelmia</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="110"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Ohita verkkotarkistus, jos se ilmoittaa virheellisen Internet-yhteyden puutteen.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <location filename="../src/main.cpp" line="130"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Olet kirjautunut sisään pääkäyttäjänä. Kirjaudu sisään normaalina käyttäjänä käyttääksesi tätä ohjelmaa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>You must run this program with admin access.</source>
        <translation>Tämä ohjelma on suoritettava järjestelmänvalvojan oikeuksilla.</translation>
    </message>
    <message>
        <location filename="../src/lockfile_pacman.cpp" line="70"/>
        <source>Pacman database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="89"/>
        <source>More info</source>
        <translation>Lisätietoa</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Paketti</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="157"/>
        <source>Info</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="161"/>
        <source>Publisher</source>
        <translation>Julkaisija</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="163"/>
        <source>Notes</source>
        <translation>Huomautukset</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="165"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
</context>
</TS>